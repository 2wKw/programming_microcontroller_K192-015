/*==============================================================================
 * Пример вычисления CRC16(CRC-16/GENIBUS) для K1921VG015
 *------------------------------------------------------------------------------
 * НИИЭТ, Александр Дыхно <dykhno@niiet.ru>
 *==============================================================================
 * ДАННОЕ ПРОГРАММНОЕ ОБЕСПЕЧЕНИЕ ПРЕДОСТАВЛЯЕТСЯ «КАК ЕСТЬ», БЕЗ КАКИХ-ЛИБО
 * ГАРАНТИЙ, ЯВНО ВЫРАЖЕННЫХ ИЛИ ПОДРАЗУМЕВАЕМЫХ, ВКЛЮЧАЯ ГАРАНТИИ ТОВАРНОЙ
 * ПРИГОДНОСТИ, СООТВЕТСТВИЯ ПО ЕГО КОНКРЕТНОМУ НАЗНАЧЕНИЮ И ОТСУТСТВИЯ
 * НАРУШЕНИЙ, НО НЕ ОГРАНИЧИВАЯСЬ ИМИ. ДАННОЕ ПРОГРАММНОЕ ОБЕСПЕЧЕНИЕ
 * ПРЕДНАЗНАЧЕНО ДЛЯ ОЗНАКОМИТЕЛЬНЫХ ЦЕЛЕЙ И НАПРАВЛЕНО ТОЛЬКО НА
 * ПРЕДОСТАВЛЕНИЕ ДОПОЛНИТЕЛЬНОЙ ИНФОРМАЦИИ О ПРОДУКТЕ, С ЦЕЛЬЮ СОХРАНИТЬ ВРЕМЯ
 * ПОТРЕБИТЕЛЮ. НИ В КАКОМ СЛУЧАЕ АВТОРЫ ИЛИ ПРАВООБЛАДАТЕЛИ НЕ НЕСУТ
 * ОТВЕТСТВЕННОСТИ ПО КАКИМ-ЛИБО ИСКАМ, ЗА ПРЯМОЙ ИЛИ КОСВЕННЫЙ УЩЕРБ, ИЛИ
 * ПО ИНЫМ ТРЕБОВАНИЯМ, ВОЗНИКШИМ ИЗ-ЗА ИСПОЛЬЗОВАНИЯ ПРОГРАММНОГО ОБЕСПЕЧЕНИЯ
 * ИЛИ ИНЫХ ДЕЙСТВИЙ С ПРОГРАММНЫМ ОБЕСПЕЧЕНИЕМ.
 *
 *                              2022 АО "НИИЭТ"
 *==============================================================================
 */

//-- Includes ------------------------------------------------------------------
#include <K1921VG015.h>
#include <stdint.h>
#include <stdio.h>
#include <system_k1921vg015.h>
#include "retarget.h"

//-- Defines -------------------------------------------------------------------
#define GPIOA_ALL_Msk	0xFFFF
#define GPIOB_ALL_Msk	0xFFFF

#define LEDS_MSK	0xFF00
#define LED0_MSK	(1 << 8)
#define LED1_MSK	(1 << 9)
#define LED2_MSK	(1 << 10)
#define LED3_MSK	(1 << 11)
#define LED4_MSK	(1 << 12)
#define LED5_MSK	(1 << 13)
#define LED6_MSK	(1 << 14)
#define LED7_MSK	(1 << 15)

#define	CRC16_GENIBUS_POLY	0x1021

void TMR32_IRQHandler();

void BSP_led_init()
{
	//Разрешаем тактирование GPIOA
	RCU->CGCFGAHB_bit.GPIOAEN = 1;
	//Включаем  GPIOA
	RCU->RSTDISAHB_bit.GPIOAEN = 1;
    GPIOA->OUTENSET = LEDS_MSK;
	GPIOA->DATAOUTSET = LEDS_MSK;
}

void TMR32_init(uint32_t period)
{
  RCU->CGCFGAPB_bit.TMR32EN = 1;
  RCU->RSTDISAPB_bit.TMR32EN = 1;

  //Записываем значение периода в CAPCOM[0]
  TMR32->CAPCOM[0].VAL = period-1;
  //Выбираем режим счета от 0 до значения CAPCOM[0]
  TMR32->CTRL_bit.MODE = 1;

  //Разрешаем прерывание по совпадению значения счетчика и CAPCOM[0]
  TMR32->IM = 2;

  // Настраиваем обработчик прерывания для TMR32
  PLIC_SetIrqHandler (Plic_Mach_Target, IsrVect_IRQ_TMR32, TMR32_IRQHandler);
  PLIC_SetPriority   (IsrVect_IRQ_TMR32, 0x1);
  PLIC_IntEnable     (Plic_Mach_Target, IsrVect_IRQ_TMR32);
}

uint32_t Get_crc16(uint8_t* buff,uint16_t count,uint16_t polynom)
{
	RCU->CGCFGAHB_bit.CRC0EN = 1;
	RCU->RSTDISAHB_bit.CRC0EN = 1;
	CRC0->CR = (CRC_CR_MODE_StandartCRC << CRC_CR_MODE_Pos) | // MODE STM32 legacy
              (0                       << CRC_CR_XOROUT_Pos) | // XOROUT 0
              (CRC_CR_POLYSIZE_POL16 << CRC_CR_POLYSIZE_Pos) | // POLYSIZE 32-bit
              (CRC_CR_REV_IN_Disable << CRC_CR_REV_IN_Pos) | // REVIN 0
              (CRC_CR_REV_OUT_Disable << CRC_CR_REV_OUT_Pos); // REVOUT 0
    CRC0->POL = polynom;
    CRC0->INIT = 0xffffffff; // standart initial value
    CRC0->CR_bit.RESET = 1; // Reset CRC0 block
    while(count)
    {
      *((volatile uint8_t *)&CRC0->DR) = *((uint8_t *) buff);
      buff++;
      count--;
    }
    return (uint32_t)CRC0->POST;
}

//-- Peripheral init functions -------------------------------------------------
void periph_init()
{
	BSP_led_init();
	SystemInit();
	SystemCoreClockUpdate();
	BSP_led_init();
	retarget_init();
	printf("K1921VG015 SYSCLK = %d MHz\n",(int)(SystemCoreClock / 1000000));
	printf("  UID[0] = 0x%X  UID[1] = 0x%X  UID[2] = 0x%X  UID[3] = 0x%X\n",(unsigned int)PMUSYS->UID[0],(unsigned int)PMUSYS->UID[1],(unsigned int)PMUSYS->UID[2],(unsigned int)PMUSYS->UID[3]);
    printf("  PartNum = 0x%X\n",(uint16_t)(PMUSYS->UID[3] >> 16));
    printf("  Calc CRC-16/GENIBUS for UID[0], UID[1], UID[2]\n");
    printf("  Result CRC-16/GENIBUS = 0x%X\n",(unsigned int)Get_crc16((uint8_t *)PMUSYS->UID[0],12,CRC16_GENIBUS_POLY));
    printf("  Start RunLeds\n");
}

//--- USER FUNCTIONS ----------------------------------------------------------------------


volatile uint32_t led_shift;
//-- Main ----------------------------------------------------------------------
int main(void)
{
  periph_init();
  TMR32_init(SystemCoreClock>>4);
  InterruptEnable();
  led_shift = LED0_MSK;
  while(1)
  {

  }

  return 0;
}


//-- IRQ INTERRUPT HANDLERS ---------------------------------------------------------------
void TMR32_IRQHandler()
{
	GPIOA->DATAOUTTGL = led_shift;
	led_shift = led_shift << 1;
    if(led_shift > LED7_MSK) led_shift = LED0_MSK;
    //Сбрасываем флаг прерывания таймера
    TMR32->IC = 3;
}
