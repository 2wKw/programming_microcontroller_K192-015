/*==============================================================================
 * Пример работы с отключением регулятор напряжения для K1921VG015 и пробуждением
 * от AntiTamper и WakeUp.
 *
 *   Первый запуск программы отпределяем по значению счетчика будильника,
 *   настраиваем пробуждение от AntiTamper (AT_IN0, AT_IN1, AT_IN2),
 *   настраиваем пробуждение от WakeUp (WAKEUP0, WAKEUP1, WAKEUP1),
 * "Моргаем" всеми светодиодами 3 раза
 *   Далее устанавливаем пробуждение через 6 секунд и отключаем оба регулятора
 * напряжения с целью минимизации потребления тока
 *   После пробуждения считываем значение регистра PMURTC->RTC_REG[0] и "моргаем"
 * соответствующим светодиодом 2 раза. Проверяем состояние AntiTamper и WakeUp
 * и выводим информацию по UART.
 *   Инкрементируем значение регистра PMURTC->RTC_REG[0], устанавливаем
 * пробуждение через 6 секунд и отключаем оба регулятора напряжения с целью
 * минимизации потребления тока
 *------------------------------------------------------------------------------
 * НИИЭТ, Александр Дыхно <dykhno@niiet.ru>
 *==============================================================================
 * ДАННОЕ ПРОГРАММНОЕ ОБЕСПЕЧЕНИЕ ПРЕДОСТАВЛЯЕТСЯ «КАК ЕСТЬ», БЕЗ КАКИХ-ЛИБО
 * ГАРАНТИЙ, ЯВНО ВЫРАЖЕННЫХ ИЛИ ПОДРАЗУМЕВАЕМЫХ, ВКЛЮЧАЯ ГАРАНТИИ ТОВАРНОЙ
 * ПРИГОДНОСТИ, СООТВЕТСТВИЯ ПО ЕГО КОНКРЕТНОМУ НАЗНАЧЕНИЮ И ОТСУТСТВИЯ
 * НАРУШЕНИЙ, НО НЕ ОГРАНИЧИВАЯСЬ ИМИ. ДАННОЕ ПРОГРАММНОЕ ОБЕСПЕЧЕНИЕ
 * ПРЕДНАЗНАЧЕНО ДЛЯ ОЗНАКОМИТЕЛЬНЫХ ЦЕЛЕЙ И НАПРАВЛЕНО ТОЛЬКО НА
 * ПРЕДОСТАВЛЕНИЕ ДОПОЛНИТЕЛЬНОЙ ИНФОРМАЦИИ О ПРОДУКТЕ, С ЦЕЛЬЮ СОХРАНИТЬ ВРЕМЯ
 * ПОТРЕБИТЕЛЮ. НИ В КАКОМ СЛУЧАЕ АВТОРЫ ИЛИ ПРАВООБЛАДАТЕЛИ НЕ НЕСУТ
 * ОТВЕТСТВЕННОСТИ ПО КАКИМ-ЛИБО ИСКАМ, ЗА ПРЯМОЙ ИЛИ КОСВЕННЫЙ УЩЕРБ, ИЛИ
 * ПО ИНЫМ ТРЕБОВАНИЯМ, ВОЗНИКШИМ ИЗ-ЗА ИСПОЛЬЗОВАНИЯ ПРОГРАММНОГО ОБЕСПЕЧЕНИЯ
 * ИЛИ ИНЫХ ДЕЙСТВИЙ С ПРОГРАММНЫМ ОБЕСПЕЧЕНИЕМ.
 *
 *                              2024 АО "НИИЭТ"
 *==============================================================================
 */

//-- Includes ------------------------------------------------------------------
#include <K1921VG015.h>
#include <stdint.h>
#include <stdio.h>
#include <system_k1921vg015.h>
#include "retarget.h"

//-- Defines -------------------------------------------------------------------

#define LEDS_MSK	0xFF00
#define LED0_MSK	(1 << 8)
#define LED1_MSK	(1 << 9)
#define LED2_MSK	(1 << 10)
#define LED3_MSK	(1 << 11)
#define LED4_MSK	(1 << 12)
#define LED5_MSK	(1 << 13)
#define LED6_MSK	(1 << 14)
#define LED7_MSK	(1 << 15)

#define RTC_EVENT_WAKEUP (PMURTC_RTC_HISTORY_WAKE0_Msk|PMURTC_RTC_HISTORY_WAKE1_Msk|PMURTC_RTC_HISTORY_WAKE2_Msk)
#define RTC_EVENT_ANTITAMPER (PMURTC_RTC_HISTORY_TAMPER0_Msk|PMURTC_RTC_HISTORY_TAMPER1_Msk|PMURTC_RTC_HISTORY_TAMPER2_Msk)
#define RTC_EVENTS (RTC_EVENT_WAKEUP | RTC_EVENT_ANTITAMPER)

void BSP_led_init()
{
	//Разрешаем тактирование GPIOA
	RCU->CGCFGAHB_bit.GPIOAEN = 1;
	//Включаем  GPIOA
	RCU->RSTDISAHB_bit.GPIOAEN = 1;
    GPIOA->OUTENSET = LEDS_MSK;
	GPIOA->DATAOUTSET = LEDS_MSK;
}

//--- USER FUNCTIONS ----------------------------------------------------------------------

void delay(uint32_t a)
{
	while(a) a--;
}

void Power_off()
{
	uint32_t WFI_ENTR_tmp;
	WFI_ENTR_tmp = PMURTC->WFI_ENTR & (PMURTC_WFI_ENTR_VL_Msk | PMURTC_WFI_ENTR_VH_Msk);
	PMURTC->RTC_CFG1 |= PMURTC_RTC_CFG1_ALARMRST_Msk; // Сбрасываем бит TIMEALARM
	PMURTC->WFI_PDEN_bit.EN = 1;
	PMURTC->WFI_ENTR = (0 << PMURTC_WFI_ENTR_LDO0EN_Pos) |
					   (0 << PMURTC_WFI_ENTR_LDO1EN_Pos) |
					   WFI_ENTR_tmp;
	__asm("WFI");
    __asm("NOP");
    __asm("NOP");
    __asm("NOP");
}

void Power_Stop()
{
	uint32_t WFI_ENTR_tmp;
	WFI_ENTR_tmp = PMURTC->WFI_ENTR & (PMURTC_WFI_ENTR_VL_Msk | PMURTC_WFI_ENTR_VH_Msk);
	PMURTC->RTC_CFG1 |= PMURTC_RTC_CFG1_ALARMRST_Msk; // Сбрасываем бит TIMEALARM
	PMURTC->WFI_PDEN_bit.EN = 1;
	PMURTC->WFI_ENTR = (1 << PMURTC_WFI_ENTR_LDO0EN_Pos) |
					   (0 << PMURTC_WFI_ENTR_LDO1EN_Pos) |
					   WFI_ENTR_tmp;
	__asm("WFI");
    __asm("NOP");
    __asm("NOP");
    __asm("NOP");
}

void WakeUp_init()
{
	  //Настраиваем кнопку SB3, подключенную к WAKEUP0
	  PMURTC->RTC_WAKECFG_bit.WAKEPOL = 0x7; // Устанавливаем полярность для WAKEUP0 - низкий уровень
	  PMURTC->RTC_WAKECFG_bit.WAKEEN = 0x7;  // Разрешаем событие WAKEUP0
	  PMURTC->RTC_HISTORY = 0x0;    // СБрасываем регистр событий
}

void AntiTamper_init()
{
	  PMURTC->RTC_WAKECFG_bit.TAMPER0EN = 1; // Разрешаем событие AT_IN0
	  PMURTC->RTC_WAKECFG_bit.TAMPER1EN = 1; // Разрешаем событие AT_IN1
	  PMURTC->RTC_WAKECFG_bit.TAMPER2EN = 1; // Разрешаем событие AT_IN2
	  // Настраиваем предел отклонения частоты следования тактов второго механизма защиты от несанкционированного доступа (AT2)
	  //PMURTC->RTC_CFG0_bit.AT2 = 0x07; //Допустимое отклонение до 23,4%
	  PMURTC->RTC_HISTORY = 0x0;    // СБрасываем регистр событий
}

volatile uint32_t led_shift;
//-- Main ----------------------------------------------------------------------
int main(void)
{
    uint32_t tmp,tmp_history, tmp_time,timeout_counter;
    uint16_t history_curr, zhistory_cnt;
    PMURTC->RTC_HISTORY = 0;
	// Запоминаем время
    tmp_time = PMURTC->RTC_TIME;
    //PMURTC->RTC_CFG1 |= PMURTC_RTC_CFG1_ALARMRST_Msk; // Сбрасываем бит TIMEALARM
    //switch sysclk
    RCU->SYSCLKCFG = (RCU_SYSCLKCFG_SRC_HSECLK << RCU_SYSCLKCFG_SRC_Pos);
    // Wait switching done
    timeout_counter = 0;
    while ((RCU->CLKSTAT_bit.SRC != RCU->SYSCLKCFG_bit.SRC) && (timeout_counter < 100)) timeout_counter++;
	SystemCoreClockUpdate();
	BSP_led_init();
	GPIOA->DATAOUTCLR = LEDS_MSK; // Включаем все светодиоды
	delay(SystemCoreClock);
	GPIOA->DATAOUTSET = LEDS_MSK; // Выключаем все светодиоды
	retarget_init();
	if (PMURTC->RTC_ALARM == 0){// Определяем первый запуск после подачи питания на микроконтроллер
		PMURTC->RTC_REG[0].RTC_REG = 0;	 // Записываем первоначальное значение
		PMURTC->RTC_CFG0_bit.EXTOSC = 1; //Переключаем тактирование RTC на внешний кварцевый резонатор 32768 Гц
		AntiTamper_init(); // Настраиваем AntiTamper
		WakeUp_init(); // Настраиваем WakeUp

		printf("First Start PowerOff+WakeUp+AntiTamper\n");
		// "Моргаем" всеми светодиодами 3 раза
		delay(SystemCoreClock >> 2);
		GPIOA->DATAOUTCLR = LEDS_MSK;
		delay(SystemCoreClock >> 2);
		GPIOA->DATAOUTSET = LEDS_MSK;
		delay(SystemCoreClock >> 2);
		GPIOA->DATAOUTCLR = LEDS_MSK;
		delay(SystemCoreClock >> 2);
		GPIOA->DATAOUTSET = LEDS_MSK;
		delay(SystemCoreClock >> 2);
		GPIOA->DATAOUTCLR = LEDS_MSK;
		delay(SystemCoreClock >> 2);
	} else {
		// Очередной не первый запуск
		printf("\n=====================================\n");
		tmp_history = 0;
    	// Запоминаем состояние событий
    	while(tmp_history == 0) {
			tmp_history = PMURTC->RTC_HISTORY  & RTC_EVENTS;
	        __asm("NOP");
	        __asm("NOP");
	        __asm("NOP");	        
	    }    
		printf("\nNext Start. Time = 0x%X  H = 0x%X\n", tmp_time,tmp_history);
		// Проверяем события AntiTamper
		if(tmp_history & RTC_EVENT_ANTITAMPER){
			printf("\nAntiTamper ALARM ON ");
			if(tmp_history & PMURTC_RTC_HISTORY_TAMPER0_Msk) { PMURTC->RTC_HISTORY_bit.TAMPER0 = 0; printf("AT_IN0, ");}
			if(tmp_history & PMURTC_RTC_HISTORY_TAMPER1_Msk) { PMURTC->RTC_HISTORY_bit.TAMPER1 = 0; printf("AT_IN1, ");}
			if(tmp_history & PMURTC_RTC_HISTORY_TAMPER2_Msk) { PMURTC->RTC_HISTORY_bit.TAMPER2 = 0; printf("AT_IN2, ");}
		}
		// Проверяем события WakeUp
		if(tmp_history & RTC_EVENT_WAKEUP){
			printf("\nWakeUp ON ");
			if(tmp_history & PMURTC_RTC_HISTORY_WAKE0_Msk) { PMURTC->RTC_HISTORY_bit.WAKE0 = 0; printf("WakeUp0, ");}
			if(tmp_history & PMURTC_RTC_HISTORY_WAKE1_Msk) { PMURTC->RTC_HISTORY_bit.WAKE1 = 0; printf("WakeUp1, ");}
			if(tmp_history & PMURTC_RTC_HISTORY_WAKE2_Msk) { PMURTC->RTC_HISTORY_bit.WAKE2 = 0; printf("WakeUp2, ");}
		}

		tmp = PMURTC->RTC_REG[0].RTC_REG & 0x07 + 8;
		tmp = (1 << tmp);
		//Моргаем светодиодом, позиция которого соответствует значению в регистре RTC (PMURTC->RTC_REG[0])
		GPIOA->DATAOUTTGL = tmp;
		delay(SystemCoreClock >> 2);
		GPIOA->DATAOUTTGL = tmp;
		delay(SystemCoreClock >> 2);
		GPIOA->DATAOUTTGL = tmp;
		delay(SystemCoreClock >> 2);
		PMURTC->RTC_REG[0].RTC_REG = PMURTC->RTC_REG[0].RTC_REG + 1;
	}

	/* Ожидаем отключения разрешенных событий, чтобы при засыпании не проснуться */
	PMURTC->RTC_HISTORY = 0;
	history_curr = PMURTC->RTC_HISTORY&RTC_EVENTS;
	printf("\nWait close Events... \n");
	zhistory_cnt = 0;
	while(zhistory_cnt < 10){
		history_curr = PMURTC->RTC_HISTORY&RTC_EVENTS;
		if((history_curr &RTC_EVENTS) == 0) zhistory_cnt++;
		else zhistory_cnt = 0;
		PMURTC->RTC_HISTORY = 0;
		__asm("NOP");
		__asm("NOP");
		__asm("NOP");
	}

	GPIOA->DATAOUTSET = LEDS_MSK; // Выключаем все светодиоды
	PMURTC->RTC_ALARM = PMURTC->RTC_TIME + 6; //Устанавливаем пробуждение через 6 секунд
	printf("Go Sleep. H = 0x%X; Time = 0x%X \n",(unsigned int)(PMURTC->RTC_HISTORY & RTC_EVENTS),(unsigned int)PMURTC->RTC_TIME);
	while(1){
		//Режим Stop
		Power_Stop();
		//PMURTC->RTC_CFG1_bit.REGEN = 1;
	    //PMURTC->RTC_CFG1 |= PMURTC_RTC_CFG1_ALARMRST_Msk;
        __asm("NOP");
        __asm("NOP");
        __asm("NOP");
        __asm("NOP");
        __asm("NOP");
        __asm("NOP");
        __asm("NOP");
        __asm("NOP");
        //Если не смогли уснуть - выполняем программный сброс микроконтроллера
        RCU->RSTSYS = 0xA55A0001;
    };
    return 0;
}


//-- IRQ INTERRUPT HANDLERS ---------------------------------------------------------------

