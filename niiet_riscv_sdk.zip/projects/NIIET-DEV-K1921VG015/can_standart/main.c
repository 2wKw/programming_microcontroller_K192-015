/*==============================================================================
 * Пример передачи стандартных CAN-сообщений (6 передач) для K1921VG015
 * Speed 1000 kbit: TSEG2 = 1; TSEG1 = 8; BRP = 4
 * CAN0 (Tx - B.9, Rx - B.8):
 *   - объекты для передачи: 0-2
 *   - объекты для приёма: 3-5
 * CAN1 (Tx - B.11, Rx - B.10):
 *   - объекты для передачи: 58-60
 *   - объекты для приёма: 61-63
 *
 *   В прерывании по регистрам ждущих прерываний определяем от какого объекта
 *   сообщения пришел запрос на прерывание
 *------------------------------------------------------------------------------
 * НИИЭТ, Александр Дыхно <dykhno@niiet.ru>
 *==============================================================================
 * ДАННОЕ ПРОГРАММНОЕ ОБЕСПЕЧЕНИЕ ПРЕДОСТАВЛЯЕТСЯ «КАК ЕСТЬ», БЕЗ КАКИХ-ЛИБО
 * ГАРАНТИЙ, ЯВНО ВЫРАЖЕННЫХ ИЛИ ПОДРАЗУМЕВАЕМЫХ, ВКЛЮЧАЯ ГАРАНТИИ ТОВАРНОЙ
 * ПРИГОДНОСТИ, СООТВЕТСТВИЯ ПО ЕГО КОНКРЕТНОМУ НАЗНАЧЕНИЮ И ОТСУТСТВИЯ
 * НАРУШЕНИЙ, НО НЕ ОГРАНИЧИВАЯСЬ ИМИ. ДАННОЕ ПРОГРАММНОЕ ОБЕСПЕЧЕНИЕ
 * ПРЕДНАЗНАЧЕНО ДЛЯ ОЗНАКОМИТЕЛЬНЫХ ЦЕЛЕЙ И НАПРАВЛЕНО ТОЛЬКО НА
 * ПРЕДОСТАВЛЕНИЕ ДОПОЛНИТЕЛЬНОЙ ИНФОРМАЦИИ О ПРОДУКТЕ, С ЦЕЛЬЮ СОХРАНИТЬ ВРЕМЯ
 * ПОТРЕБИТЕЛЮ. НИ В КАКОМ СЛУЧАЕ АВТОРЫ ИЛИ ПРАВООБЛАДАТЕЛИ НЕ НЕСУТ
 * ОТВЕТСТВЕННОСТИ ПО КАКИМ-ЛИБО ИСКАМ, ЗА ПРЯМОЙ ИЛИ КОСВЕННЫЙ УЩЕРБ, ИЛИ
 * ПО ИНЫМ ТРЕБОВАНИЯМ, ВОЗНИКШИМ ИЗ-ЗА ИСПОЛЬЗОВАНИЯ ПРОГРАММНОГО ОБЕСПЕЧЕНИЯ
 * ИЛИ ИНЫХ ДЕЙСТВИЙ С ПРОГРАММНЫМ ОБЕСПЕЧЕНИЕМ.
 *
 *                              2025 АО "НИИЭТ"
 *==============================================================================
 */

//-- Includes ------------------------------------------------------------------
#include <K1921VG015.h>
#include <stdint.h>
#include <stdio.h>
#include <system_k1921vg015.h>
#include "retarget.h"

//-- Defines -------------------------------------------------------------------
#define GPIOA_ALL_Msk 0xFFFF
#define GPIOB_ALL_Msk 0xFFFF

#define LEDS_MSK  0xFF00
#define LED0_MSK  (1 << 8)
#define LED1_MSK  (1 << 9)
#define LED2_MSK  (1 << 10)
#define LED3_MSK  (1 << 11)
#define LED4_MSK  (1 << 12)
#define LED5_MSK  (1 << 13)
#define LED6_MSK  (1 << 14)
#define LED7_MSK  (1 << 15)

//-- Types ---------------------------------------------------------------------
typedef enum {
    CAN_OPERATION_TX,
    CAN_OPERATION_RX,
    CAN_OPERATION_TXRX
} CAN_Operation_TypeDef;

typedef enum {
    CAN_MESSAGE_REMOTE,
    CAN_MESSAGE_COMMON
} CAN_Message_TypeDef;

//-- Variables -----------------------------------------------------------------
static uint32_t OK_MODATAL = 0;
static uint32_t ERR_MODATAL = 0;
static uint32_t OK_MODATAH = 0;
static uint32_t ERR_MODATAH = 0;
volatile uint32_t IRQ_COUNT = 0;

//__attribute__((interrupt))
void TMR32_IRQHandler();
//__attribute__((interrupt))
void CAN_line0_IRQHandler();
//__attribute__((interrupt))
void CAN_line1_IRQHandler();

//-- CAN service functions -----------------------------------------------------
void CAN_Object_Location(uint32_t obj_first_num, uint32_t obj_last_num,
                         uint32_t list_num)
{
    unsigned int x;

    // LOCATION OBJECTS TO THE LISTS
    for (x = obj_first_num; x <= obj_last_num; x++) {
        // PANCMD_field=0x02-static location objects to one of the CAN-lists
        CAN->PANCTR = (0x2 << CAN_PANCTR_PANCMD_Pos) |
                      (x << CAN_PANCTR_PANAR1_Pos) |
                      (list_num << CAN_PANCTR_PANAR2_Pos);

        while ((CAN->PANCTR_bit.BUSY) | (CAN->PANCTR_bit.RBUSY)) {
        };
    }
}

void CAN_Object_Config(uint32_t obj_num, CAN_Operation_TypeDef op_type,
                       CAN_Message_TypeDef msg_type)
{
    if (op_type == CAN_OPERATION_TX) {
        if (msg_type == CAN_MESSAGE_COMMON)
            CANMSG->Msg[obj_num].MOCTR = CANMSG_Msg_MOCTR_SETDIR_Msk |
                                         CANMSG_Msg_MOCTR_SETTXEN0_Msk |
                                         CANMSG_Msg_MOCTR_SETTXEN1_Msk;
        else if (msg_type == CAN_MESSAGE_REMOTE)
            CANMSG->Msg[obj_num].MOCTR = CANMSG_Msg_MOCTR_RESDIR_Msk |
                                         CANMSG_Msg_MOCTR_SETTXEN0_Msk |
                                         CANMSG_Msg_MOCTR_SETTXEN1_Msk;
    } else if (op_type == CAN_OPERATION_RX) {
        if (msg_type == CAN_MESSAGE_COMMON)
            CANMSG->Msg[obj_num].MOCTR = CANMSG_Msg_MOCTR_RESDIR_Msk | CANMSG_Msg_MOCTR_SETRXEN_Msk;
        else if (msg_type == CAN_MESSAGE_REMOTE)
            CANMSG->Msg[obj_num].MOCTR = CANMSG_Msg_MOCTR_SETDIR_Msk | CANMSG_Msg_MOCTR_SETRXEN_Msk;
    } else if (op_type == CAN_OPERATION_TXRX) {
        if (msg_type == CAN_MESSAGE_COMMON)
            CANMSG->Msg[obj_num].MOCTR = CANMSG_Msg_MOCTR_SETDIR_Msk | CANMSG_Msg_MOCTR_SETTXEN0_Msk |
                                         CANMSG_Msg_MOCTR_SETTXEN1_Msk | CANMSG_Msg_MOCTR_SETRXEN_Msk;
        else if (msg_type == CAN_MESSAGE_REMOTE)
            CANMSG->Msg[obj_num].MOCTR = CANMSG_Msg_MOCTR_RESDIR_Msk | CANMSG_Msg_MOCTR_SETTXEN0_Msk |
                                         CANMSG_Msg_MOCTR_SETTXEN1_Msk | CANMSG_Msg_MOCTR_SETRXEN_Msk;
    }
}

void CAN_Object_Transmit(uint32_t obj_num)
{
    CANMSG->Msg[obj_num].MOCTR = CANMSG_Msg_MOCTR_SETTXRQ_Msk | CANMSG_Msg_MOCTR_SETMSGVAL_Msk;
}

void CAN_Object_Receive(uint32_t obj_num)
{
    CANMSG->Msg[obj_num].MOCTR = CANMSG_Msg_MOCTR_SETMSGVAL_Msk;
}

void CAN_CompareData(uint32_t tx_obj_num, uint32_t rx_obj_num)
{
    if (CANMSG->Msg[rx_obj_num].MODATAL != CANMSG->Msg[tx_obj_num].MODATAL)
        ERR_MODATAL += 1;
    else
        OK_MODATAL += 1;

    if (CANMSG->Msg[rx_obj_num].MODATAH != CANMSG->Msg[tx_obj_num].MODATAH)
        ERR_MODATAH += 1;
    else
        OK_MODATAH += 1;
}

void CAN_CompareDataBlock(uint32_t first_tx_obj_num, uint32_t first_rx_obj_num,
                          uint32_t trans_total)
{
    for (uint32_t x = 0; x < trans_total; x++) {
        CAN_CompareData(first_tx_obj_num, first_rx_obj_num);
        first_tx_obj_num += 1;
        first_rx_obj_num += 1;
    }
}

/* Функция настройки бита ожидания
 * obj_num - номер объекта сообщения, для которого настроиваем ждущее прерывание
 * mspnd_bitnum - номер бита ожидания от 0 до 127
 * */
void CANMSG_SetMSPND(uint8_t obj_num,uint8_t mspnd_bitnum)
{
  uint8_t mspnd_num,mspnd_pos;
  mspnd_num = (mspnd_bitnum & 0x1E) >> 5;
  mspnd_pos = mspnd_bitnum & 0x1F;
  CANMSG->Msg[obj_num].MOIPR_bit.MPN =  (mspnd_num << 6) | mspnd_pos;
}

/* Функция проверки статуса бита ожидания
 * mspnd_bitnum - номер бита ожидания от 0 до 127
 * */
uint8_t CAN_GetMSPNDState(uint8_t mspnd_bitnum)
{
  uint8_t mspnd_num,mspnd_pos;
  mspnd_num = (mspnd_bitnum & 0x1E) >> 5;
  mspnd_pos = mspnd_bitnum & 0x1F;
  if (CAN->MSPND[mspnd_num].MSPND & (1 << mspnd_pos)) return 1;
  else return 0;
}

/* Функция очистки статуса бита ожидания
 * mspnd_bitnum - номер бита ожидания от 0 до 127
 * */
void CAN_ClearMSPNDState(uint8_t mspnd_bitnum)
{
  uint8_t mspnd_num,mspnd_pos;
  mspnd_num = (mspnd_bitnum & 0x1E) >> 5;
  mspnd_pos = mspnd_bitnum & 0x1F;
  CAN->MSPND[mspnd_num].MSPND &= ~(1 << mspnd_pos);
}
//-- Peripheral init functions -------------------------------------------------
void can_init()
{
    // IO
    RCU->CGCFGAHB_bit.GPIOBEN = 1;
    RCU->RSTDISAHB_bit.GPIOBEN = 1;
    GPIOB->ALTFUNCNUM_bit.PIN8 = 1;
    GPIOB->ALTFUNCNUM_bit.PIN9 = 1;
    GPIOB->ALTFUNCNUM_bit.PIN10 = 1;
    GPIOB->ALTFUNCNUM_bit.PIN11 = 1;
    GPIOB->ALTFUNCSET = 0x0F00;

    // Clock and reset
    RCU->CGCFGAHB_bit.CANEN = 1;
    RCU->RSTDISAHB_bit.CANEN = 1;
    CAN->CLC_bit.DISR = 0;

    while ((CAN->CLC_bit.DISS) & (CAN->PANCTR_bit.PANCMD)) {
    };
    CAN->FDR = (0x1 << CAN_FDR_DM_Pos) |
               (0x3FF << CAN_FDR_STEP_Pos); // normal divider mode
    // Fin = SysClk = 50 000 000 Hz
    // Enable the change configuration of the CAN node's
    // CAN0 and CAN1 are disconnected from the bus
    // Speed CAN - 1000 kbit: TSEG2 = 1; TSEG1 = 8; BRP = 4
    CAN->Node[0].NCR = CAN_Node_NCR_CCE_Msk | CAN_Node_NCR_INIT_Msk;
    CAN->Node[0].NBTR = (0 << CAN_Node_NBTR_TSEG2_Pos) | (7 << CAN_Node_NBTR_TSEG1_Pos) |
                        (0x1 << CAN_Node_NBTR_SJW_Pos) | (4 << CAN_Node_NBTR_BRP_Pos);
    CAN->Node[1].NCR = CAN_Node_NCR_CCE_Msk | CAN_Node_NCR_INIT_Msk;
    CAN->Node[1].NBTR = (0 << CAN_Node_NBTR_TSEG2_Pos) | (7 << CAN_Node_NBTR_TSEG1_Pos) |
                        (0x1 << CAN_Node_NBTR_SJW_Pos) | (4 << CAN_Node_NBTR_BRP_Pos);

    // CAN0, CAN1 is connected with the bus, node's interrupts are enable
    CAN->Node[0].NCR = CAN_Node_NCR_TRIE_Msk;
    CAN->Node[1].NCR = CAN_Node_NCR_TRIE_Msk;

    // choosing number lines for node's interrupts
    CAN->Node[0].NIPR = (1 << CAN_Node_NIPR_TRINP_Pos);
    CAN->Node[1].NIPR = (1 << CAN_Node_NIPR_TRINP_Pos);

    CAN->Node[0].NPCR = CAN_Node_NPCR_LBM_Msk;
    CAN->Node[1].NPCR = CAN_Node_NPCR_LBM_Msk;

    // Настраиваем обработчик прерывания для CAN Line0
    PLIC_SetIrqHandler (Plic_Mach_Target, IsrVect_IRQ_CAN0, CAN_line0_IRQHandler);
    PLIC_SetPriority   (IsrVect_IRQ_CAN0, 0x1);
    PLIC_IntEnable     (Plic_Mach_Target, IsrVect_IRQ_CAN0);

    // Настраиваем обработчик прерывания для CAN Line1
    PLIC_SetIrqHandler (Plic_Mach_Target, IsrVect_IRQ_CAN1, CAN_line1_IRQHandler);
    PLIC_SetPriority   (IsrVect_IRQ_CAN1, 0x1);
    PLIC_IntEnable     (Plic_Mach_Target, IsrVect_IRQ_CAN1);
}

void BSP_led_init()
{
  //Разрешаем тактирование GPIOA
  RCU->CGCFGAHB_bit.GPIOAEN = 1;
  //Включаем  GPIOA
  RCU->RSTDISAHB_bit.GPIOAEN = 1;
    GPIOA->OUTENSET = LEDS_MSK;
  GPIOA->DATAOUTSET = LEDS_MSK;
}

void TMR32_init(uint32_t period)
{
  RCU->CGCFGAPB_bit.TMR32EN = 1;
  RCU->RSTDISAPB_bit.TMR32EN = 1;

  //Записываем значение периода в CAPCOM[0]
  TMR32->CAPCOM[0].VAL = period-1;
  //Выбираем режим счета от 0 до значения CAPCOM[0]
  TMR32->CTRL_bit.MODE = 1;

  //Разрешаем прерывание по совпадению значения счетчика и CAPCOM[0]
  TMR32->IM = 2;

  // Настраиваем обработчик прерывания для TMR32
  PLIC_SetIrqHandler (Plic_Mach_Target, IsrVect_IRQ_TMR32, TMR32_IRQHandler);
  PLIC_SetPriority   (IsrVect_IRQ_TMR32, 0x1);
  PLIC_IntEnable     (Plic_Mach_Target, IsrVect_IRQ_TMR32);
}


//-- Peripheral init functions -------------------------------------------------
void periph_init()
{
  BSP_led_init();
  SystemInit();
  SystemCoreClockUpdate();
  BSP_led_init();
  retarget_init();
  can_init();
  printf("K1921VG015 SYSCLK = %d MHz\n",(int)(SystemCoreClock / 1E6));
  printf("  UID[0] = 0x%X  UID[1] = 0x%X  UID[2] = 0x%X  UID[3] = 0x%X\n",(unsigned int)PMUSYS->UID[0],(unsigned int)PMUSYS->UID[1],(unsigned int)PMUSYS->UID[2],(unsigned int)PMUSYS->UID[3]);
    printf("  CAN standart\n");
}

//--- USER FUNCTIONS ----------------------------------------------------------------------

void Can_test()
{
  static const uint32_t can_id[6] = {0xA0010000,0xA0020000,0xA0030000,0xA0040000,0xA0050000,0xA0060000};
  char *can_state[8] = {"NoErr", "StuffErr", "FormErr", "AckErr", "Bit1Err", "Bit0Err", "CRCErr", "WriteEn"};
  uint32_t can_data_l,can_data_h;
  uint32_t temp_MOAR;
  uint32_t timeout;

  //printf("Set object location to the lists\n");
  while (CAN->PANCTR_bit.BUSY) {
  };
  // Location 0-5 objects to the 1 list (0 node)
  CAN_Object_Location(0, 5, 1);
  // Location 58-63 objects to the 2 list (1 node)
  CAN_Object_Location(58, 63, 2);

  printf("Prepare objects and data for transmit\n");
  can_data_l = 0x1000F000;
  can_data_h = 0xF0101010;
  for (uint32_t x = 0; x <= 2; x++) {
      CAN_Object_Config(x, CAN_OPERATION_TX, CAN_MESSAGE_COMMON);
      // Set lenth of data in the CAN-object, enable interrupts
      CANMSG->Msg[x].MOFCR = (0x8 << CANMSG_Msg_MOFCR_DLC_Pos) | CANMSG_Msg_MOFCR_TXIE_Msk ;
      // number line of CAN-object's successfull transmission interrupt
      CANMSG->Msg[x].MOIPR = (0x0 << CANMSG_Msg_MOIPR_TXINP_Pos);
      // Fill data to transmit
      CANMSG->Msg[x].MODATAL = can_data_l;
      CANMSG->Msg[x].MODATAH = can_data_h;
      can_data_l = can_data_l + 0x00010001;
      can_data_h = can_data_h + 0x00010001;
  }

  for (uint32_t x = 58; x <= 60; x++) {
      CAN_Object_Config(x, CAN_OPERATION_TX, CAN_MESSAGE_COMMON);
      // Set lenth of data in the CAN-object, enable interrupts
      CANMSG->Msg[x].MOFCR = (0x8 << CANMSG_Msg_MOFCR_DLC_Pos) | // Send 8 byte
                             CANMSG_Msg_MOFCR_TXIE_Msk;
      // number line of CAN-object's successfull transmission interrupt
      CANMSG->Msg[x].MOIPR = (0x0 << CANMSG_Msg_MOIPR_TXINP_Pos);
      // Fill data to transmit
      CANMSG->Msg[x].MODATAL = can_data_l;
      CANMSG->Msg[x].MODATAH = can_data_h;
      can_data_l = can_data_l + 0x00020002;
      can_data_h = can_data_h + 0x00020002;
  }
  // Write ID msg for transmit
  // identifiers:  0xA0010000(0 obj)/0xA0020000(1 obj)/0xA0030000(2 obj)
  // identifiers: 0xA0040000(58 obj)/0xA0050000(59 obj)/0xA0060000(60 obj)
  temp_MOAR = (0x2 << CANMSG_Msg_MOAR_PRI_Pos) | // filtration by identifier
              CANMSG_Msg_MOAR_IDE_Msk;           // extended identifier
  CANMSG->Msg[0].MOAR =  temp_MOAR | can_id[0];
  CANMSG->Msg[1].MOAR =  temp_MOAR | can_id[1];
  CANMSG->Msg[2].MOAR =  temp_MOAR | can_id[2];
  CANMSG->Msg[58].MOAR = temp_MOAR | can_id[3];
  CANMSG->Msg[59].MOAR = temp_MOAR | can_id[4];
  CANMSG->Msg[60].MOAR = temp_MOAR | can_id[5];

  printf("Prepare objects for receive\n");
  temp_MOAR = (0x2 << CANMSG_Msg_MOAR_PRI_Pos) | // filtration by identifier
              CANMSG_Msg_MOAR_IDE_Msk;           // extended identifier

  for (uint32_t x = 61; x <= 63; x++) {
      CAN_Object_Config(x, CAN_OPERATION_RX, CAN_MESSAGE_COMMON);
      // identifiers: 0xA0010000(61 obj)/0xA0020000(62 obj)/0xA0030000(63 obj)
      temp_MOAR = temp_MOAR + 0x00010000;
      CANMSG->Msg[x].MOAR = temp_MOAR;

      CANMSG->Msg[x].MOFCR = (0x8 << CANMSG_Msg_MOFCR_DLC_Pos) |
                             CANMSG_Msg_MOFCR_RXIE_Msk;
      CANMSG->Msg[x].MOIPR = (0x1 << CANMSG_Msg_MOIPR_RXINP_Pos);
  }

  for (uint32_t x = 3; x <= 5; x++) {
      CAN_Object_Config(x, CAN_OPERATION_RX, CAN_MESSAGE_COMMON);
      // identifiers: 0xA0040000(3 obj)/0xA0050000(4 obj)/0xA0060000(5 obj)
      temp_MOAR = temp_MOAR + 0x00010000;
      CANMSG->Msg[x].MOAR = temp_MOAR;

      CANMSG->Msg[x].MOFCR = (0x8 << CANMSG_Msg_MOFCR_DLC_Pos) |
                             CANMSG_Msg_MOFCR_RXIE_Msk;
      CANMSG->Msg[x].MOIPR = (0x1 << CANMSG_Msg_MOIPR_RXINP_Pos);
  }

  // Write ID msg for receive
  // identifiers: 0xA0010000(61 obj)/0xA0020000(62 obj)/0xA0030000(63 obj)
  // identifiers: 0xA0040000(3 obj)/0xA0050000(4 obj)/0xA0060000(5 obj)
  temp_MOAR = (0x2 << CANMSG_Msg_MOAR_PRI_Pos) | // filtration by identifier
              CANMSG_Msg_MOAR_IDE_Msk;           // extended identifier
  CANMSG->Msg[61].MOAR = temp_MOAR | can_id[0];
  CANMSG->Msg[62].MOAR = temp_MOAR | can_id[1];
  CANMSG->Msg[63].MOAR = temp_MOAR | can_id[2];
  CANMSG->Msg[3].MOAR =  temp_MOAR | can_id[3];
  CANMSG->Msg[4].MOAR =  temp_MOAR | can_id[4];
  CANMSG->Msg[5].MOAR =  temp_MOAR | can_id[5];

  // Настраиваем ждущие прерывания для объектов Узла 0
  // MSG_SetMSPND([Номер объекта сообщения],[номер бита от 0 до 127]);
  // Tx
  CANMSG_SetMSPND(0,0);
  CANMSG_SetMSPND(1,1);
  CANMSG_SetMSPND(2,2);
  // Rx
  CANMSG_SetMSPND(3,3);
  CANMSG_SetMSPND(4,4);
  CANMSG_SetMSPND(5,5);
  // Настраиваем ждущие прерывания для объектов Узла 1
  // Tx
  CANMSG_SetMSPND(58,32);
  CANMSG_SetMSPND(59,33);
  CANMSG_SetMSPND(60,34);
  // Rx
  CANMSG_SetMSPND(61,35);
  CANMSG_SetMSPND(62,36);
  CANMSG_SetMSPND(63,37);

  IRQ_COUNT = 0;

  printf("Start transmission!\n");
  for (uint32_t x = 61; x <= 63; x++)
      CAN_Object_Receive(x);
  for (uint32_t x = 3; x <= 5; x++)
      CAN_Object_Receive(x);

  for (uint32_t x = 0; x <= 2; x++)
      CAN_Object_Transmit(x);
  for (uint32_t x = 58; x <= 60; x++)
      CAN_Object_Transmit(x);

  // waiting 12 irqs
  timeout = SystemCoreClock;
  while ((IRQ_COUNT < 12) && (timeout > 0)) {timeout--; };

  if(timeout == 0){
    printf("CAN stop by TimeOut\n State Node[0] = %i (%s)\n State Node[1] = %i (%s)\n",
        CAN->Node[0].NSR_bit.LEC,can_state[CAN->Node[0].NSR_bit.LEC],CAN->Node[1].NSR_bit.LEC,can_state[CAN->Node[1].NSR_bit.LEC]);
    if(CAN->Node[0].NSR_bit.LEC == CAN_Node_NSR_LEC_Bit0Err) printf("Please check connection Node[0] to CAN Line (Tx - B.9, Rx - B.8).\n");
    if(CAN->Node[1].NSR_bit.LEC == CAN_Node_NSR_LEC_Bit0Err) printf("Please check connection Node[1] to CAN Line (Tx - B.11, Rx - B.10).\n");
  } else {
    printf("Check results ...\n");
      CAN_CompareDataBlock(0, 61, 3);
      CAN_CompareDataBlock(58, 3, 3);

      if ((ERR_MODATAL == 0) & (ERR_MODATAH == 0) & (OK_MODATAL == 6) &
      (OK_MODATAH == 6)) {
          printf("All data transmitted successfuly!\n");
          GPIOA->DATAOUTCLR = LED7_MSK;
      }
  }
}

volatile uint32_t led_shift;
//-- Main ----------------------------------------------------------------------
int main(void)
{
  periph_init();
  TMR32_init(SystemCoreClock>>4);
  InterruptEnable();
  led_shift = LED0_MSK;
  Can_test();

  while (1) {
  };

  return 0;
}


//-- IRQ INTERRUPT HANDLERS ---------------------------------------------------------------
void TMR32_IRQHandler()
{
  GPIOA->DATAOUTTGL = led_shift;
  led_shift = led_shift << 1;
    if(led_shift > LED6_MSK) led_shift = LED0_MSK;
    //Сбрасываем флаг прерывания таймера
    TMR32->IC = 3;
}

void CAN_line0_IRQHandler()
{
  IRQ_COUNT++;
}

void CAN_line1_IRQHandler()
{
  IRQ_COUNT++;
  if(CAN->MSPND[0].MSPND > 0){
    if(CAN_GetMSPNDState(0)){
      //Ждущее прерывание от объекта сообщения №0
    } else if(CAN_GetMSPNDState(1)){
      //Ждущее прерывание от объекта сообщения №1
    } else if(CAN_GetMSPNDState(2)){
      //Ждущее прерывание от объекта сообщения №2
    } else if(CAN_GetMSPNDState(3)){
      //Ждущее прерывание от объекта сообщения №3
    } else if(CAN_GetMSPNDState(4)){
      //Ждущее прерывание от объекта сообщения №4
    } else if(CAN_GetMSPNDState(5)){
      //Ждущее прерывание от объекта сообщения №5
    }
  } else if(CAN->MSPND[1].MSPND > 0){
    if(CAN_GetMSPNDState(32)){
      //Ждущее прерывание от объекта сообщения №58
    } else if(CAN_GetMSPNDState(33)){
      //Ждущее прерывание от объекта сообщения №59
    } else if(CAN_GetMSPNDState(34)){
      //Ждущее прерывание от объекта сообщения №60
    } else if(CAN_GetMSPNDState(35)){
      //Ждущее прерывание от объекта сообщения №61
    } else if(CAN_GetMSPNDState(36)){
      //Ждущее прерывание от объекта сообщения №62
    } else if(CAN_GetMSPNDState(37)){
      //Ждущее прерывание от объекта сообщения №63
    }
  }
}
