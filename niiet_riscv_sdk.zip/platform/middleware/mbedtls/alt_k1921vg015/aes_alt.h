#ifndef AES_ALT_H__
#define AES_ALT_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct CRYPTO_Init mbedtls_aes_context;

#ifdef __cplusplus
}
#endif

#endif
