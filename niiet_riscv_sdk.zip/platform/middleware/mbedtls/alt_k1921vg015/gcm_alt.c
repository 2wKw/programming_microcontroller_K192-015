#include <crypto_util.h>
#include <gcm.h>

void mbedtls_gcm_init(mbedtls_gcm_context *ctx)
{
    memset(ctx, 0, sizeof(mbedtls_gcm_context));
}

void mbedtls_gcm_free(mbedtls_gcm_context *ctx)
{
    if (ctx == NULL) {
        return;
    }

    mbedtls_platform_zeroize(ctx, sizeof(mbedtls_gcm_context));
}

int mbedtls_gcm_setkey(mbedtls_gcm_context *ctx,
                       mbedtls_cipher_id_t cipher,
                       const unsigned char *key,
                       unsigned int keybits)
{
	if (keybits != 128 && keybits != 256)
		return MBEDTLS_ERR_GCM_BAD_INPUT;

    if (cipher != MBEDTLS_CIPHER_ID_AES) // no other for mbedtls supported
        return MBEDTLS_ERR_GCM_BAD_INPUT;

    ctx->crypto->Algorithm = (keybits == 256) ? CRYPTO_Algo_AES_256 : CRYPTO_Algo_AES_128;
    ctx->crypto->Mode = CRYPTO_Mode_GCM;
    ctx->crypto->InitVectorAutoUpdate = ENABLE;
    ctx->crypto->UpdateKey = ENABLE;

	crypto_set_key(ctx->crypto, key);
	return 0;
}

int mbedtls_gcm_crypt_and_tag(mbedtls_gcm_context *ctx,
                              int mode,
                              size_t length,
                              const unsigned char *iv,
                              size_t iv_len,
                              const unsigned char *add,
                              size_t add_len,
                              const unsigned char *input,
                              unsigned char *output,
                              size_t tag_len,
                              unsigned char *tag)
{
    ctx->crypto->Direction = (mode == MBEDTLS_GCM_ENCRYPT) ? 0 : 1;

    return crypto_gcm_crypt_with_dma(ctx->crypto, NULL, input, length, iv, (uint32_t*) add, add_len, (uint32_t*) output, (uint32_t*) tag);
}

int mbedtls_gcm_auth_decrypt(mbedtls_gcm_context *ctx,
                             size_t length,
                             const unsigned char *iv,
                             size_t iv_len,
                             const unsigned char *add,
                             size_t add_len,
                             const unsigned char *tag,
                             size_t tag_len,
                             const unsigned char *input,
                             unsigned char *output)
{
    int ret = MBEDTLS_ERR_ERROR_CORRUPTION_DETECTED;
    unsigned char check_tag[16];
    int diff;

    if ((ret = mbedtls_gcm_crypt_and_tag(ctx, MBEDTLS_GCM_DECRYPT, length,
                                         iv, iv_len, add, add_len,
                                         input, output, tag_len, check_tag)) != 0) {
        return ret;
    }

    /* Check tag in "constant-time" */
    diff = mbedtls_ct_memcmp(tag, check_tag, tag_len);

    if (diff != 0) {
        mbedtls_platform_zeroize(output, length);
        return MBEDTLS_ERR_GCM_AUTH_FAILED;
    }

    return 0;
}

int mbedtls_gcm_starts(mbedtls_gcm_context *ctx,
                       int mode,
                       const unsigned char *iv,
                       size_t iv_len)
{
    ctx->crypto->Direction = (mode == MBEDTLS_GCM_ENCRYPT) ? CRYPTO_Dir_Encrypt : CRYPTO_Dir_Decrypt;

    return crypto_gcm_init(ctx->crypto, iv);
}

// add_len should be dividable by 16
int mbedtls_gcm_update_ad(mbedtls_gcm_context *ctx,
                          const unsigned char *add,
                          size_t add_len)
{
    ctx->additional_size = add_len;

    return crypto_gcm_header(ctx->crypto, add, add_len);
}

// input_length should be dividable by 16
int mbedtls_gcm_update(mbedtls_gcm_context *ctx,
                       const unsigned char *input, size_t input_length,
                       unsigned char *output, size_t output_size,
                       size_t *output_length)
{
    ctx->payload_size = input_length;

    return crypto_gcm_payload(ctx->crypto, input, input_length, output);
}

int mbedtls_gcm_finish(mbedtls_gcm_context *ctx,
                       unsigned char *output, size_t output_size,
                       size_t *output_length,
                       unsigned char *tag, size_t tag_len)
{
    return crypto_gcm_last_block(ctx->crypto, ctx->additional_size, ctx->payload_size, tag);
}
