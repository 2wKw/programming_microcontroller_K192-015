#ifndef TRNG_UTIL_H__
#define TRNG_UTIL_H__

#include <stdlib.h>
#include <plib015_trng.h>
#include <stdint.h>

int generate_random_data(unsigned char* output, size_t len);
int mbedtls_entropy_trng(void *data, unsigned char *output, size_t len, size_t *olen);

#endif
