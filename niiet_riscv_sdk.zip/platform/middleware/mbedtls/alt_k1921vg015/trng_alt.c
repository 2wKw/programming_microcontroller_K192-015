#include "trng_alt.h"

void init_trng(mbedtls_entropy_context *ctx)
{
        mbedtls_entropy_add_source(ctx, mbedtls_entropy_trng, NULL, NULL, MBEDTLS_ENTROPY_SOURCE_STRONG);
}
