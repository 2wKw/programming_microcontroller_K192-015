#include "crypto_util.h"
#include "aes.h"


void mbedtls_aes_init(mbedtls_aes_context *ctx)
{
	CRYPTO_StructInit((CRYPTO_Init_TypeDef*) ctx);
}

void mbedtls_aes_free(mbedtls_aes_context *ctx)
{
    if (ctx == NULL) {
        return;
    }

    mbedtls_platform_zeroize(ctx, sizeof(mbedtls_aes_context));
}

MBEDTLS_CHECK_RETURN_TYPICAL
int mbedtls_aes_setkey_enc(mbedtls_aes_context *ctx, const unsigned char *key,
                           unsigned int keybits)
{
	if (keybits != 128 && keybits != 256)
		return MBEDTLS_ERR_AES_INVALID_KEY_LENGTH;

	ctx->Direction = CRYPTO_Dir_Encrypt;
	crypto_set_key((CRYPTO_Init_TypeDef*) ctx, key);

	return 0;
}

#if !defined(MBEDTLS_BLOCK_CIPHER_NO_DECRYPT)

MBEDTLS_CHECK_RETURN_TYPICAL
int mbedtls_aes_setkey_dec(mbedtls_aes_context *ctx, const unsigned char *key,
                           unsigned int keybits)
{
	if (keybits == 128)
		ctx->Algorithm = CRYPTO_Algo_AES_128;
	else if (keybits == 256)
		ctx->Algorithm = CRYPTO_Algo_AES_256;
	else
		return MBEDTLS_ERR_AES_INVALID_KEY_LENGTH;

	ctx->Direction = CRYPTO_Dir_Decrypt;
	crypto_set_key((CRYPTO_Init_TypeDef*) ctx, key);

	return 0;
}

#endif

MBEDTLS_CHECK_RETURN_TYPICAL
int mbedtls_aes_crypt_ecb(mbedtls_aes_context *ctx,
                          int mode,
                          const unsigned char input[16],
                          unsigned char output[16])
{
	ctx->Direction = (mode == MBEDTLS_AES_ENCRYPT) ? CRYPTO_Dir_Encrypt : CRYPTO_Dir_Decrypt;
	ctx->Mode = CRYPTO_Mode_ECB;

	crypto_single_perform((CRYPTO_Init_TypeDef*) ctx, NULL, input, NULL, output);
	return 0;
}

#if defined(MBEDTLS_CIPHER_MODE_CBC)

MBEDTLS_CHECK_RETURN_TYPICAL
int mbedtls_aes_crypt_cbc(mbedtls_aes_context *ctx,
                          int mode,
                          size_t length,
                          unsigned char iv[16],
                          const unsigned char *input,
                          unsigned char *output)
{
	ctx->Direction = (mode == MBEDTLS_AES_ENCRYPT) ? CRYPTO_Dir_Encrypt : CRYPTO_Dir_Decrypt;
	ctx->Mode = CRYPTO_Mode_CBC;

	crypto_crypt_with_dma((CRYPTO_Init_TypeDef*) ctx, NULL, input, length, iv, output);
	return 0;
}

#endif

#if defined(MBEDTLS_CIPHER_MODE_CTR)

MBEDTLS_CHECK_RETURN_TYPICAL
int mbedtls_aes_crypt_ctr(mbedtls_aes_context *ctx,
                          size_t length,
                          size_t *nc_off,
                          unsigned char nonce_counter[16],
                          unsigned char stream_block[16],
                          const unsigned char *input,
                          unsigned char *output)
{
//	ctx->Direction = CRYPTO_Dir_Encrypt;
	ctx->Mode = CRYPTO_Mode_CTR;

	crypto_crypt_with_dma((CRYPTO_Init_TypeDef*) ctx, NULL, input, length, nonce_counter, output);
	return 0;
}

#endif

MBEDTLS_CHECK_RETURN_TYPICAL
int mbedtls_internal_aes_encrypt(mbedtls_aes_context *ctx,
                                 const unsigned char input[16],
                                 unsigned char output[16])
{
	// no need in this function
	return 0;
}

#if !defined(MBEDTLS_BLOCK_CIPHER_NO_DECRYPT)

MBEDTLS_CHECK_RETURN_TYPICAL
int mbedtls_internal_aes_decrypt(mbedtls_aes_context *ctx,
                                 const unsigned char input[16],
                                 unsigned char output[16])
{
	// no need in this function
	return 0;
}

#endif
