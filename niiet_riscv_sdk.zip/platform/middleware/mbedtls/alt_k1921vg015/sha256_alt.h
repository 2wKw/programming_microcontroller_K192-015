#ifndef SHA256_ALT_H__
#define SHA256_ALT_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "hash_util.h"

/**
 * \brief          The SHA-256 context structure.
 *
 *                 The structure is used both for SHA-256 and for SHA-224
 *                 checksum calculations. The choice between these two is
 *                 made in the call to mbedtls_sha256_starts().
 */
typedef struct {
	struct hash_context ctx;
	uint32_t is224;
} mbedtls_sha256_context;

#ifdef __cplusplus
}
#endif

#endif
