#ifndef GCM_ALT_H__
#define GCM_ALT_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <plib015_crypto.h>

typedef struct mbedtls_gcm_context {
    uint32_t additional_size;
    uint32_t payload_size;
    CRYPTO_Init_TypeDef* crypto;
} mbedtls_gcm_context;

#ifdef __cplusplus
}
#endif

#endif
