#ifndef HASH_UTIL_H__
#define HASH_UTIL_H__

#include <plib015_hash.h>
#include <stdlib.h>
#include <stdint.h>

typedef struct hash_context {
	uint32_t length;
	uint32_t last_word;
} hash_context_t;

void hash_start(HASH_ALGO_TypeDef algo);
int hash_update(hash_context_t* ctx, const unsigned char* input, size_t ilen);
int hash_finish(hash_context_t* ctx, unsigned char* output);
void hash_with_dma(unsigned char* message, size_t message_len, unsigned char* result, HASH_ALGO_TypeDef algo);

#endif
