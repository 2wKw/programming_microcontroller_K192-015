#ifndef SHA1_ALT_H__
#define SHA1_ALT_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "hash_util.h"

/**
 * \brief          SHA1 context structure (empty type)
 *
 * \warning        SHA-1 is considered a weak message digest and its use
 *                 constitutes a security risk. We recommend considering
 *                 stronger message digests instead.
 *
 */
typedef struct hash_context mbedtls_sha1_context;

#ifdef __cplusplus
}
#endif

#endif
