#include "hash_util.h"
#include "sha256.h"

void mbedtls_sha256_init(mbedtls_sha256_context *ctx)
{
	ctx->ctx.length = 0;
	ctx->ctx.last_word = 0;
	ctx->is224 = 0;
}

void mbedtls_sha256_free(mbedtls_sha256_context *ctx)
{
    if (ctx == NULL) {
        return;
    }

    mbedtls_platform_zeroize(ctx, sizeof(mbedtls_sha256_context));
}

void mbedtls_sha256_clone(mbedtls_sha256_context *dst, const mbedtls_sha256_context *src)
{
	*dst = *src;

}

int mbedtls_sha256_starts(mbedtls_sha256_context *ctx, int is224)
{
	ctx->is224 = is224;
	if (ctx->is224)
		hash_start(HASH_ALGO_SHA224);
	else
		hash_start(HASH_ALGO_SHA256);
	return 0;
}

int mbedtls_sha256_update(mbedtls_sha256_context *ctx, const unsigned char *input, size_t ilen)
{
	return hash_update(&ctx->ctx, input, ilen);
}

int mbedtls_sha256_finish(mbedtls_sha256_context *ctx, unsigned char *output)
{
	return hash_finish(&ctx->ctx, output);
}

int mbedtls_internal_sha256_process(mbedtls_sha256_context *ctx, const unsigned char data[64])
{
	(void) ctx;
	(void) data;
}

int mbedtls_sha256(const unsigned char *input, size_t ilen, unsigned char *output, int is224)
{
	if (is224)
		hash_with_dma(input, ilen, output, HASH_ALGO_SHA224);
	else
		hash_with_dma(input, ilen, output, HASH_ALGO_SHA256);
}
