#ifndef MD5_ALT_H__
#define MD5_ALT_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "hash_util.h"

/**
 * \brief          MD5 context structure (empty type)
 *
 * \warning        MD5 is considered a weak message digest and its use
 *                 constitutes a security risk. We recommend considering
 *                 stronger message digests instead.
 *
 */
typedef struct hash_context mbedtls_md5_context;

#ifdef __cplusplus
}
#endif

#endif
