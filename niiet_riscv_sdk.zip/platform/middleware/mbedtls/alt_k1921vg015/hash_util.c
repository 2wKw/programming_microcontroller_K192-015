#include "hash_util.h"

static void hash_get_hash_in_bytes(unsigned char* output)
{
	while(HASH_BusyStatus()) {}

	uint32_t hash[8];
	uint32_t hash_len = HASH_GetHashBuffer(hash);

	while(hash_len--)
	{
		output[4 * hash_len + 3] = hash[hash_len] & 0x000000FF;
		output[4 * hash_len + 2] = (hash[hash_len] & 0x0000FF00) >> 8;
		output[4 * hash_len + 1] = (hash[hash_len] & 0x00FF0000) >> 16;
		output[4 * hash_len    ] = (hash[hash_len] & 0xFF000000) >> 24;
	}
}

void hash_start(HASH_ALGO_TypeDef algo)
{
	HASH_Init_TypeDef hash;
	HASH_StructInit(&hash);

	hash.DataType = HASH_DATATYPE_Byte;
	hash.Mode = HASH_MODE_Hash;
	hash.Algo = algo;

	HASH_Init(&hash);
}

int hash_update(hash_context_t* ctx, const unsigned char* input, size_t ilen)
{
	while (ctx->length % 4)
	{
		ctx->last_word = ctx->last_word + ((*input++) << (8 * ctx->length));
		++ctx->length;
		--ilen;
	}

	if (ctx->last_word != 0)
	{
		HASH_SetData(ctx->last_word);
	}

	ctx->length += ilen;

	while (ilen > 4)
	{
		uint32_t word = (*input++) + ((*input++) << 8) + ((*input++) << 16) + ((*input++) << 24);
		ilen -= 4;

		HASH_SetData(word);
	}
	ctx->last_word = 0;
	uint8_t it;
	if (ilen > 0)
		while (it < ilen)
		{
			ctx->last_word = ctx->last_word + ((*input++) << (8 * it++));
		}
}

int hash_finish(hash_context_t* ctx, unsigned char* output)
{
	HASH_SetLastWordLength((ctx->length % 4) << 3);

	HASH_SetData(ctx->last_word);

	HASH_StartCmd(ENABLE);

	hash_get_hash_in_bytes(output);

	return 0;
}

void hash_with_dma(unsigned char* message, size_t message_len, unsigned char* result, HASH_ALGO_TypeDef algo)
{
	static DMA_CtrlData_TypeDef DMA_CTRLDATA __attribute__((aligned (1024)));

	uint32_t word_length = message_len / 4 + (message_len % 4 ? 1 : 0);

	HASH_Init_TypeDef hash;
	HASH_StructInit(&hash);

	hash.DataType = HASH_DATATYPE_Byte;
	hash.Mode = HASH_MODE_Hash;
	hash.Algo = algo;

	HASH_SetLastWordLength((message_len % 4) << 3);

	HASH_Init(&hash);

	DMA_BasePtrConfig(&DMA_CTRLDATA);
	DMA_ChannelInit_TypeDef dmaChannel;
	DMA_ChannelStructInit(&dmaChannel);

	dmaChannel.SrcDataSize = DMA_DataSize_32;
	dmaChannel.SrcDataInc = DMA_DataInc_32;

	dmaChannel.DstDataSize = DMA_DataSize_32;
	dmaChannel.DstDataInc = DMA_DataInc_Disable;

	dmaChannel.ArbitrationRate = DMA_ArbitrationRate_1;
	dmaChannel.TransfersTotal = word_length;
	dmaChannel.Mode = DMA_Mode_Basic;

	dmaChannel.SrcDataEndPtr = &(message[message_len - 1]);
	dmaChannel.DstDataEndPtr = &(HASH->DATAIN);
	DMA_Channel_TypeDef dmaPRMHashChannel;
	DMA_ChannelInit(&dmaPRMHashChannel, &dmaChannel);
	DMA_CTRLDATA.PRM_DATA.CH[22] = dmaPRMHashChannel;

	DMA_ChannelEnableCmd(DMA_Channel_HASH, ENABLE);
	DMA_MasterEnableCmd(ENABLE);

	HASH_DMACmd(ENABLE);

	hash_get_hash_in_bytes(result);
}
