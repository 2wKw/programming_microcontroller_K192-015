#include "hash_util.h"
#include "sha1.h"

void mbedtls_sha1_init(mbedtls_sha1_context *ctx)
{
	ctx->length = 0;
	ctx->last_word = 0;
}

void mbedtls_sha1_free(mbedtls_sha1_context *ctx)
{
    if (ctx == NULL) {
        return;
    }

    mbedtls_platform_zeroize(ctx, sizeof(mbedtls_sha1_context));
}

void mbedtls_sha1_clone(mbedtls_sha1_context *dst, const mbedtls_sha1_context *src)
{
	*dst = *src;

}

int mbedtls_sha1_starts(mbedtls_sha1_context *ctx)
{
	(void*) ctx;

	hash_start(HASH_ALGO_SHA1);
	return 0;
}

int mbedtls_sha1_update(mbedtls_sha1_context *ctx, const unsigned char *input, size_t ilen)
{
	return hash_update(ctx, input, ilen);
}

int mbedtls_sha1_finish(mbedtls_sha1_context *ctx, unsigned char output[20])
{
	return hash_finish(ctx, output);
}

int mbedtls_internal_sha1_process(mbedtls_sha1_context *ctx, const unsigned char data[64])
{
	(void) ctx;
	(void) data;
}

int mbedtls_sha1(const unsigned char *input, size_t ilen, unsigned char output[20])
{
	hash_with_dma(input, ilen, output, HASH_ALGO_SHA1);
}
