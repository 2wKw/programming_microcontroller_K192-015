#include "trng_util.h"

int generate_random_data(unsigned char* output, size_t len)
{
	TRNG_SwResetCmd(ENABLE);
	TRNG_Init_TypeDef trngInit;
	TRNG_StructInit(&trngInit);

	trngInit.WarmPeriod       		= 0x00000200;
	trngInit.SamplePeriod     		= 0x00000020;
	trngInit.CoolPeriod       		= 0x00000000;
	trngInit.AmountBlocksForHandler = 0x0;
	trngInit.BypassHandler    		= ENABLE;

	TRNG_Init(&trngInit);

	TRNG_StartCmd(ENABLE);

	uint32_t fifo;
	while(len)
	{
		len -= 4;
		while(!TRNG_GetFIFOlength()) {}
		fifo = TRNG_GetFIFOValue();
		if (len < 0)
		{
			len = 0;
			break;
		}
		output[len] = (fifo & 0xFF000000) >> 24;
		output[len + 1] = (fifo & 0x00FF0000) >> 16;
		output[len + 2] = (fifo & 0x0000FF00) >> 8;
		output[len + 3] = fifo & 0x000000FF;
	}

	TRNG_StartCmd(DISABLE);
}

int mbedtls_entropy_trng(void *data, unsigned char *output, size_t len, size_t *olen)
{
	*olen = len;
	return generate_random_data(output, len);
}
