#ifndef CRYPTO_UTIL_H__
#define CRYPTO_UTIL_H__

#include <plib015_crypto.h>


// Методы модуля

// размер ключа, который будет записан определяется функцией crypto_set_keysize, по сути должен отличаться только для AES-128
void crypto_set_key(CRYPTO_Init_TypeDef* crypto, const unsigned char* key);

// выбор режима шифрования
void crypto_set_mode(CRYPTO_Init_TypeDef* crypto, CRYPTO_Mode_TypeDef mode);

// выбор алгоритма
void crypto_set_algorithm(CRYPTO_Init_TypeDef* crypto, CRYPTO_Algo_TypeDef algo);

// установить инициализационный вектор
void crypto_set_iv(const unsigned char *iv);

void crypto_set_encrypt(CRYPTO_Init_TypeDef* crypto);
void crypto_set_decrypt(CRYPTO_Init_TypeDef* crypto);


// ECB, CBC, CTR режимы

// Единичная операция над блоком данных для шифрования, для всех шифров кроме MAGMA размер блоков должен быть равен 128 битам, для MAGMA - 64 бита
// Функция ДОЛЖНА получать блоки входных данных, кратные размеру блока выбранного шифра
// Эти функции не будут работать с режимом GCM
void crypto_single_perform(CRYPTO_Init_TypeDef* crypto, const unsigned char *key, const unsigned char *data_in, const unsigned char* iv, unsigned char *data_out);
void crypto_crypt_with_dma(CRYPTO_Init_TypeDef* crypto, const unsigned char *key, const unsigned char *data_in, uint32_t data_in_size, const unsigned char* iv, unsigned char *data_out);



// GCM режим

uint32_t crypto_gcm_crypt_with_dma(CRYPTO_Init_TypeDef* crypto, const unsigned char *key, const uint32_t *data_in, uint32_t data_in_size,
									const unsigned char* iv, const uint32_t *additional, uint32_t additional_size, uint32_t *data_out, uint32_t *tag);
uint32_t crypto_gcm_init(CRYPTO_Init_TypeDef* crypto, const unsigned char *iv);
uint32_t crypto_gcm_header(CRYPTO_Init_TypeDef* crypto, const unsigned char *additional, uint32_t additional_size);
uint32_t crypto_gcm_payload(CRYPTO_Init_TypeDef* crypto, const unsigned char *input, uint32_t input_length, unsigned char *output);
uint32_t crypto_gcm_last_block(CRYPTO_Init_TypeDef* crypto, uint32_t additional_size, uint32_t payload_size, unsigned char *tag);

#endif
