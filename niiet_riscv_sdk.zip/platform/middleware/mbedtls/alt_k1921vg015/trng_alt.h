#ifndef TRNG_ALT_H__
#define TRNG_ALT_H__

#include <entropy.h>
#include "trng_util.h"

void init_trng(mbedtls_entropy_context *ctx);

#endif
