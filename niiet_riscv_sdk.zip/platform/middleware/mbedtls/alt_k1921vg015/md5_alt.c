#include "hash_util.h"
#include "md5.h"

void mbedtls_md5_init(mbedtls_md5_context *ctx)
{
	ctx->length = 0;
	ctx->last_word = 0;
}

void mbedtls_md5_free(mbedtls_md5_context *ctx)
{
    if (ctx == NULL) {
        return;
    }

    mbedtls_platform_zeroize(ctx, sizeof(mbedtls_md5_context));
}

void mbedtls_md5_clone(mbedtls_md5_context *dst, const mbedtls_md5_context *src)
{
	*dst = *src;

}

int mbedtls_md5_starts(mbedtls_md5_context *ctx)
{
	(void*) ctx;

	hash_start(HASH_ALGO_MD5);

	return 0;
}

int mbedtls_md5_update(mbedtls_md5_context *ctx, const unsigned char *input, size_t ilen)
{
	// handle last word
	return hash_update(ctx, input, ilen);
}

int mbedtls_md5_finish(mbedtls_md5_context *ctx, unsigned char output[16])
{
	return hash_finish(ctx, output);
}

int mbedtls_internal_md5_process(mbedtls_md5_context *ctx, const unsigned char data[64])
{
	(void) ctx;
	(void) data;
}

int mbedtls_md5(const unsigned char *input, size_t ilen, unsigned char output[16])
{
	hash_with_dma(input, ilen, output, HASH_ALGO_MD5);
}
