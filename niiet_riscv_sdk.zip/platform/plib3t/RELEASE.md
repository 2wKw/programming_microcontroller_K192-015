# История изменений

# v1.0.0
- Добавлены файлы библиотеки для модулей периферии: ACMP, ADC, CRC, CRYPTO, FLASH, GPIO, HASH, I2C, PWM, QEP, QSPI, RCU, SPI, TMR, UART, WDT.
