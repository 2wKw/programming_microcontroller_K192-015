/**
  ******************************************************************************
  * @file    plib3t_rcu.h
  *
  * @brief   Файл содержит прототипы и компактные inline реализации функций для
  *          RCU (Reset & Clock control Unit), а также сопутствующие
  *          макроопределения и перечисления
  *
  * @author  НИИЭТ, Александр Дыхно <dykhno@niiet.ru>
  *
  ******************************************************************************
  * @attention
  *
  * ДАННОЕ ПРОГРАММНОЕ ОБЕСПЕЧЕНИЕ ПРЕДОСТАВЛЯЕТСЯ «КАК ЕСТЬ», БЕЗ КАКИХ-ЛИБО
  * ГАРАНТИЙ, ЯВНО ВЫРАЖЕННЫХ ИЛИ ПОДРАЗУМЕВАЕМЫХ, ВКЛЮЧАЯ ГАРАНТИИ ТОВАРНОЙ
  * ПРИГОДНОСТИ, СООТВЕТСТВИЯ ПО ЕГО КОНКРЕТНОМУ НАЗНАЧЕНИЮ И ОТСУТСТВИЯ
  * НАРУШЕНИЙ, НО НЕ ОГРАНИЧИВАЯСЬ ИМИ. ДАННОЕ ПРОГРАММНОЕ ОБЕСПЕЧЕНИЕ
  * ПРЕДНАЗНАЧЕНО ДЛЯ ОЗНАКОМИТЕЛЬНЫХ ЦЕЛЕЙ И НАПРАВЛЕНО ТОЛЬКО НА
  * ПРЕДОСТАВЛЕНИЕ ДОПОЛНИТЕЛЬНОЙ ИНФОРМАЦИИ О ПРОДУКТЕ, С ЦЕЛЬЮ СОХРАНИТЬ ВРЕМЯ
  * ПОТРЕБИТЕЛЮ. НИ В КАКОМ СЛУЧАЕ АВТОРЫ ИЛИ ПРАВООБЛАДАТЕЛИ НЕ НЕСУТ
  * ОТВЕТСТВЕННОСТИ ПО КАКИМ-ЛИБО ИСКАМ, ЗА ПРЯМОЙ ИЛИ КОСВЕННЫЙ УЩЕРБ, ИЛИ
  * ПО ИНЫМ ТРЕБОВАНИЯМ, ВОЗНИКШИМ ИЗ-ЗА ИСПОЛЬЗОВАНИЯ ПРОГРАММНОГО ОБЕСПЕЧЕНИЯ
  * ИЛИ ИНЫХ ДЕЙСТВИЙ С ПРОГРАММНЫМ ОБЕСПЕЧЕНИЕМ.
  *
  * <h2><center>&copy; 2025 АО "НИИЭТ"</center></h2>
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __PLIB3T_RCU_H
#define __PLIB3T_RCU_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "plib3t.h"

/** @addtogroup Peripheral
  * @{
  */

/** @defgroup RCU
  * @brief Драйвер для работы с тактированием и сбросом периферийных блоков
  * @{
  */

/** @defgroup RCU_Exported_Defines Константы
  * @{
  */

#define HSICLK_VAL 4000000
#define HSECLK_VAL 16000000
#define EXTCLK_VAL 10000000

/** @defgroup RCU_ClkStatus_Define Cтатусы источников тактового сигнала
  * @{
  */

#define RCU_ClkStatus_HSEClkFail RCU_CLKSTAT_CLKERR1_Msk          /*!< Ошибка сигнала внешнего осциллятора */
#define RCU_ClkStatus_PLLClkFail RCU_CLKSTAT_CLKERR2_Msk          /*!< Ошибка сигнала с PLL */
#define RCU_ClkStatus_LSIClkFail RCU_CLKSTAT_CLKERR3_Msk          /*!< Ошибка сигнала с LSI */
#define RCU_ClkStatus_HSEClkGood RCU_CLKSTAT_CLKGOOD1_Msk         /*!< Нормальная работа сигнала внешнего осциллятора */
#define RCU_ClkStatus_PLLClkGood RCU_CLKSTAT_CLKGOOD2_Msk         /*!< Нормальная работа сигнала с PLL */
#define RCU_ClkStatus_EXTClkGood RCU_CLKSTAT_CLKGOOD3_Msk         /*!< Нормальная работа сигнала с LSI */

#define IS_RCU_CLK_STATUS(VALUE) (((VALUE) == RCU_ClkStatus_HSEClkFail) ||    \
                                  ((VALUE) == RCU_ClkStatus_PLLClkFail) ||    \
                                  ((VALUE) == RCU_ClkStatus_LSIClkFail) ||    \
                                  ((VALUE) == RCU_ClkStatus_HSEClkGood) ||    \
                                  ((VALUE) == RCU_ClkStatus_PLLClkGood) ||    \
                                  ((VALUE) == RCU_ClkStatus_EXTClkGood))
/**
  * @}
  */

/** @defgroup RCU_RstStatus_Define Источник, вызвавший последний сброс системы
  * @{
  */

#define RCU_RstStatus_POR     RCU_RSTSTAT_POR_Msk         /*!< Сброс от блока POR */
#define RCU_RstStatus_WDOG    RCU_RSTSTAT_WDOG_Msk        /*!< Сброс от сторожевого таймера */
#define RCU_RstStatus_Sys     RCU_RSTSTAT_SYSRST_Msk      /*!< Системный сброс */

#define IS_RCU_RST_STATUS(VALUE) (((VALUE) == RCU_RstStatus_POR) || \
                                  ((VALUE) == RCU_RstStatus_WDOG) || \
                                  ((VALUE) == RCU_RstStatus_Sys))
/**
  * @}
  */

/** @defgroup RCU_ITSource_Define Источники прерываний
  * @{
  */

#define RCU_ITSource_SRCClkFail RCU_INTEN_SRCCLKERR_Msk       /*!< Произошла ошибка сигнала внешнего осциллятора */
#define RCU_ITSource_PLLClkFail RCU_INTEN_PLLCLKERR_Msk       /*!< Произошла ошибка сигнала с PLL */
#define RCU_ITSource_PLLDivClkFail RCU_INTEN_PLLDIVCLKERR_Msk /*!< Произошла ошибка сигнала с деленного выхода PLL */
#define RCU_ITSource_SRCClkGood RCU_INTEN_SRCCLKOK_Msk        /*!< Произошел переход к нормальной работе сигнала внешнего осциллятора */
#define RCU_ITSource_PLLClkGood RCU_INTEN_PLLCLKOK_Msk        /*!< Произошел переход к нормальной работе сигнала с PLL */
#define RCU_ITSource_PLLDivClkGood RCU_INTEN_PLLDIVCLKOK_Msk  /*!< Произошел переход к нормальной работе сигнала с деленного выхода PLL */
#define RCU_ITSource_PLLLock RCU_INTEN_PLLLOCK_Msk            /*!< Произошел захват частоты PLL */

#define IS_RCU_IT_SOURCE(VALUE) (((VALUE) == RCU_ITSource_SRCClkFail) ||    \
                                 ((VALUE) == RCU_ITSource_PLLClkFail) ||    \
                                 ((VALUE) == RCU_ITSource_PLLDivClkFail) || \
                                 ((VALUE) == RCU_ITSource_SRCClkGood) ||    \
                                 ((VALUE) == RCU_ITSource_PLLClkGood) ||    \
                                 ((VALUE) == RCU_ITSource_PLLDivClkGood) || \
                                 ((VALUE) == RCU_ITSource_PLLLock))

/**
  * @}
  */

/** @defgroup RCU_ITStatus_Define Статусы прерываний
  * @{
  */

#define RCU_ITStatus_SRCClkFail RCU_INTSTAT_SRCCLKERR_Msk       /*!< Флаг ошибки сигнала внешнего осциллятора */
#define RCU_ITStatus_PLLClkFail RCU_INTSTAT_PLLCLKERR_Msk       /*!< Флаг ошибки сигнала с PLL */
#define RCU_ITStatus_SRCClkGood RCU_INTSTAT_SRCCLKOK_Msk        /*!< Флаг перехода к нормальной работе сигнала внешнего осциллятора */
#define RCU_ITStatus_PLLClkGood RCU_INTSTAT_PLLCLKOK_Msk        /*!< Флаг перехода к нормальной работе сигнала с PLL */
#define RCU_ITStatus_PLLLock    RCU_INTSTAT_PLLLOCK_Msk            /*!< Флаг захвата частоты PLL */
#define RCU_ITStatus_PLLFail    RCU_INTSTAT_PLLFAIL_Msk            /*!< Флаг сбоя системной частоты */

#define IS_RCU_IT_STATUS(VALUE) (((VALUE) == RCU_ITStatus_SRCClkFail) ||    \
                                 ((VALUE) == RCU_ITStatus_PLLClkFail) ||    \
                                 ((VALUE) == RCU_ITStatus_SRCClkGood) ||    \
                                 ((VALUE) == RCU_ITStatus_PLLClkGood) ||    \
                                 ((VALUE) == RCU_ITStatus_PLLLock) ||       \
                                 ((VALUE) == RCU_ITStatus_PLLFail))

/**
  * @}
  */

/** @defgroup RCU_AHBClk_Define Управление тактированием периферийных блоков AHB
  * @{
  */

#define RCU_AHBClk_GPIOA    RCU_RSTDISAHB_GPIOAEN_Msk   /*!< Управление тактированием блока GPIOA */
#define RCU_AHBClk_GPIOB    RCU_RSTDISAHB_GPIOBEN_Msk   /*!< Управление тактированием блока GPIOB */
#define RCU_AHBClk_GPIOC    RCU_RSTDISAHB_GPIOCEN_Msk   /*!< Управление тактированием блока GPIOC */
#define RCU_AHBClk_GPIOD    RCU_RSTDISAHB_GPIODEN_Msk   /*!< Управление тактированием блока GPIOD */
#define RCU_AHBClk_GPIOE    RCU_RSTDISAHB_GPIOEEN_Msk   /*!< Управление тактированием блока GPIOE */
#define RCU_AHBClk_GPIOF    RCU_RSTDISAHB_GPIOFEN_Msk   /*!< Управление тактированием блока GPIOF */
#define RCU_AHBClk_GPIOG    RCU_RSTDISAHB_GPIOGEN_Msk   /*!< Управление тактированием блока GPIOG */
#define RCU_AHBClk_GPIOH    RCU_RSTDISAHB_GPIOHEN_Msk   /*!< Управление тактированием блока GPIOH */
#define RCU_AHBClk_CAN      RCU_RSTDISAHB_CANEN_Msk     /*!< Управление тактированием блока CAN */
#define RCU_AHBClk_ADC      RCU_RSTDISAHB_ADCEN_Msk     /*!< Управление тактированием блока ADC */
#define RCU_AHBClk_QSPI     RCU_RSTDISAHB_QSPIEN_Msk    /*!< Управление тактированием блока QSPI */
#define RCU_AHBClk_CRC      RCU_RSTDISAHB_CRCEN_Msk     /*!< Управление тактированием блока CRC */
#define RCU_AHBClk_HASH     RCU_RSTDISAHB_HASHEN_Msk    /*!< Управление тактированием блока HASH */
#define RCU_AHBClk_CRYPTO   RCU_RSTDISAHB_CRYPTOEN_Msk  /*!< Управление тактированием блока CRYPTO */
#define RCU_AHBClk_USBD     RCU_RSTDISAHB_USBDEN_Msk    /*!< Управление тактированием блока USBD */
#define RCU_AHBClk_USBH     RCU_RSTDISAHB_USBHEN_Msk    /*!< Управление тактированием блока USBH */
#define RCU_AHBClk_CANFD0   RCU_RSTDISAHB_CANFD0EN_Msk  /*!< Управление тактированием блока CANFD0 */
#define RCU_AHBClk_CANFD1   RCU_RSTDISAHB_CANFD1EN_Msk  /*!< Управление тактированием блока CANFD1 */

#define IS_RCU_AHB_CLK(VALUE)   (((VALUE) == RCU_AHBClk_GPIOA) || \
								 ((VALUE) == RCU_AHBClk_GPIOB ) || \
								 ((VALUE) == RCU_AHBClk_GPIOC ) || \
								 ((VALUE) == RCU_AHBClk_GPIOD ) || \
								 ((VALUE) == RCU_AHBClk_GPIOE ) || \
								 ((VALUE) == RCU_AHBClk_GPIOF ) || \
								 ((VALUE) == RCU_AHBClk_GPIOG ) || \
								 ((VALUE) == RCU_AHBClk_GPIOH ) || \
								 ((VALUE) == RCU_AHBClk_CAN   ) || \
								 ((VALUE) == RCU_AHBClk_ADC   ) || \
								 ((VALUE) == RCU_AHBClk_QSPI  ) || \
								 ((VALUE) == RCU_AHBClk_CRC   ) || \
								 ((VALUE) == RCU_AHBClk_HASH  ) || \
								 ((VALUE) == RCU_AHBClk_CRYPTO) || \
								 ((VALUE) == RCU_AHBClk_USBD  ) || \
								 ((VALUE) == RCU_AHBClk_USBH  ) || \
								 ((VALUE) == RCU_AHBClk_CANFD0) || \
                                 ((VALUE) == RCU_AHBClk_CANFD1))

/**
  * @}
  */

/** @defgroup RCU_APB0Clk_Define Управление тактированием периферийных блоков 0 APB
  * @{
  */

#define RCU_APBClk0_DMA   RCU_CGCFGAPB0_DMAEN_Msk      /*!< Управление тактированием блока DMA   */
#define RCU_APBClk0_FLASH RCU_CGCFGAPB0_FLASHEN_Msk    /*!< Управление тактированием блока FLASH */
#define RCU_APBClk0_RAM   RCU_CGCFGAPB0_RAMEN_Msk      /*!< Управление тактированием блока RAM   */
#define RCU_APBClk0_RTC   RCU_CGCFGAPB0_RTCEN_Msk      /*!< Управление тактированием блока RTC   */
#define RCU_APBClk0_WDT   RCU_CGCFGAPB0_WDTEN_Msk      /*!< Управление тактированием блока WDT   */
#define RCU_APBClk0_TRNG  RCU_CGCFGAPB0_TRNGEN_Msk     /*!< Управление тактированием блока TRNG  */
#define RCU_APBClk0_EMC   RCU_CGCFGAPB0_EMCEN_Msk      /*!< Управление тактированием блока EMC   */
#define RCU_APBClk0_CAP0  RCU_CGCFGAPB0_CAP0EN_Msk     /*!< Управление тактированием блока CAP0  */
#define RCU_APBClk0_CAP1  RCU_CGCFGAPB0_CAP1EN_Msk     /*!< Управление тактированием блока CAP1  */
#define RCU_APBClk0_CAP2  RCU_CGCFGAPB0_CAP2EN_Msk     /*!< Управление тактированием блока CAP2  */
#define RCU_APBClk0_CAP3  RCU_CGCFGAPB0_CAP3EN_Msk     /*!< Управление тактированием блока CAP3  */
#define RCU_APBClk0_CAP4  RCU_CGCFGAPB0_CAP4EN_Msk     /*!< Управление тактированием блока CAP4  */
#define RCU_APBClk0_CAP5  RCU_CGCFGAPB0_CAP5EN_Msk     /*!< Управление тактированием блока CAP5  */
#define RCU_APBClk0_DAC0  RCU_CGCFGAPB0_DAC0EN_Msk     /*!< Управление тактированием блока DAC0  */
#define RCU_APBClk0_DAC1  RCU_CGCFGAPB0_DAC1EN_Msk     /*!< Управление тактированием блока DAC1  */
#define RCU_APBClk0_TMR0  RCU_CGCFGAPB0_TMR0EN_Msk     /*!< Управление тактированием блока TMR0  */
#define RCU_APBClk0_TMR1  RCU_CGCFGAPB0_TMR1EN_Msk     /*!< Управление тактированием блока TMR1  */
#define RCU_APBClk0_TMR2  RCU_CGCFGAPB0_TMR2EN_Msk     /*!< Управление тактированием блока TMR2  */
#define RCU_APBClk0_TMR3  RCU_CGCFGAPB0_TMR3EN_Msk     /*!< Управление тактированием блока TMR3  */
#define RCU_APBClk0_TMR4  RCU_CGCFGAPB0_TMR4EN_Msk     /*!< Управление тактированием блока TMR4  */
#define RCU_APBClk0_TMR5  RCU_CGCFGAPB0_TMR5EN_Msk     /*!< Управление тактированием блока TMR5  */
#define RCU_APBClk0_TMR6  RCU_CGCFGAPB0_TMR6EN_Msk     /*!< Управление тактированием блока TMR6  */
#define RCU_APBClk0_TMR7  RCU_CGCFGAPB0_TMR7EN_Msk     /*!< Управление тактированием блока TMR7  */
#define RCU_APBClk0_TMR8  RCU_CGCFGAPB0_TMR8EN_Msk     /*!< Управление тактированием блока TMR8  */
#define RCU_APBClk0_TMR9  RCU_CGCFGAPB0_TMR9EN_Msk     /*!< Управление тактированием блока TMR9  */
#define RCU_APBClk0_TMR10 RCU_CGCFGAPB0_TMR10EN_Msk    /*!< Управление тактированием блока TMR10 */
#define RCU_APBClk0_TMR11 RCU_CGCFGAPB0_TMR11EN_Msk    /*!< Управление тактированием блока TMR11 */
#define RCU_APBClk0_TMR12 RCU_CGCFGAPB0_TMR12EN_Msk    /*!< Управление тактированием блока TMR12 */
#define RCU_APBClk0_TMR13 RCU_CGCFGAPB0_TMR13EN_Msk    /*!< Управление тактированием блока TMR13 */
#define RCU_APBClk0_TMR14 RCU_CGCFGAPB0_TMR14EN_Msk    /*!< Управление тактированием блока TMR14 */
#define RCU_APBClk0_TMR15 RCU_CGCFGAPB0_TMR15EN_Msk    /*!< Управление тактированием блока TMR15 */

#define IS_RCU_APB0_CLK(VALUE)  (((VALUE) == RCU_APBClk0_DMA) ||  \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_FLASH) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_RAM  ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_RTC  ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_WDT  ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_TRNG ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_EMC  ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_CAP0 ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_CAP1 ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_CAP2 ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_CAP3 ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_CAP4 ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_CAP5 ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_DAC0 ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_DAC1 ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_TMR0 ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_TMR1 ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_TMR2 ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_TMR3 ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_TMR4 ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_TMR5 ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_TMR6 ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_TMR7 ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_TMR8 ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_TMR9 ) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_TMR10) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_TMR11) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_TMR12) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_TMR13) || \
		 	 	 	 	 	 	 ((VALUE) == RCU_APBClk0_TMR14) || \
                                 ((VALUE) == RCU_APBClk0_TMR15))

/**
  * @}
  */

/** @defgroup RCU_APB1Clk_Define Управление тактированием периферийных блоков APB 1
  * @{
  */

#define RCU_APBClk1_ACMP0 RCU_CGCFGAPB1_ACMP0EN_Msk    /*!< Управление тактированием блока ACMP0 */
#define RCU_APBClk1_ACMP1 RCU_CGCFGAPB1_ACMP1EN_Msk    /*!< Управление тактированием блока ACMP1 */
#define RCU_APBClk1_ACMP2 RCU_CGCFGAPB1_ACMP2EN_Msk    /*!< Управление тактированием блока ACMP2 */
#define RCU_APBClk1_SDRAM RCU_CGCFGAPB1_SDRAMEN_Msk    /*!< Управление тактированием блока SDRAM */
#define RCU_APBClk1_LIN0  RCU_CGCFGAPB1_LIN0EN_Msk     /*!< Управление тактированием блока LIN0  */
#define RCU_APBClk1_LIN1  RCU_CGCFGAPB1_LIN1EN_Msk     /*!< Управление тактированием блока LIN1  */
#define RCU_APBClk1_LIN2  RCU_CGCFGAPB1_LIN2EN_Msk     /*!< Управление тактированием блока LIN2  */
#define RCU_APBClk1_LIN3  RCU_CGCFGAPB1_LIN3EN_Msk     /*!< Управление тактированием блока LIN3  */
#define RCU_APBClk1_SPI0  RCU_CGCFGAPB1_SPI0EN_Msk     /*!< Управление тактированием блока SPI0  */
#define RCU_APBClk1_SPI1  RCU_CGCFGAPB1_SPI1EN_Msk     /*!< Управление тактированием блока SPI1  */
#define RCU_APBClk1_SPI2  RCU_CGCFGAPB1_SPI2EN_Msk     /*!< Управление тактированием блока SPI2  */
#define RCU_APBClk1_SPI3  RCU_CGCFGAPB1_SPI3EN_Msk     /*!< Управление тактированием блока SPI3  */
#define RCU_APBClk1_I2C0  RCU_CGCFGAPB1_I2C0EN_Msk     /*!< Управление тактированием блока I2C0  */
#define RCU_APBClk1_I2C1  RCU_CGCFGAPB1_I2C1EN_Msk     /*!< Управление тактированием блока I2C1  */
#define RCU_APBClk1_QEP0  RCU_CGCFGAPB1_QEP0EN_Msk     /*!< Управление тактированием блока QEP0  */
#define RCU_APBClk1_QEP1  RCU_CGCFGAPB1_QEP1EN_Msk     /*!< Управление тактированием блока QEP1  */
#define RCU_APBClk1_UART0 RCU_CGCFGAPB1_UART0EN_Msk    /*!< Управление тактированием блока UART0 */
#define RCU_APBClk1_UART1 RCU_CGCFGAPB1_UART1EN_Msk    /*!< Управление тактированием блока UART1 */
#define RCU_APBClk1_UART2 RCU_CGCFGAPB1_UART2EN_Msk    /*!< Управление тактированием блока UART2 */
#define RCU_APBClk1_UART3 RCU_CGCFGAPB1_UART3EN_Msk    /*!< Управление тактированием блока UART3 */
#define RCU_APBClk1_UART4 RCU_CGCFGAPB1_UART4EN_Msk    /*!< Управление тактированием блока UART4 */
#define RCU_APBClk1_UART5 RCU_CGCFGAPB1_UART5EN_Msk    /*!< Управление тактированием блока UART5 */
#define RCU_APBClk1_ETH   RCU_CGCFGAPB1_ETHEN_Msk      /*!< Управление тактированием блока ETH   */
#define RCU_APBClk1_PWM0  RCU_CGCFGAPB1_PWM0EN_Msk     /*!< Управление тактированием блока PWM0  */
#define RCU_APBClk1_PWM1  RCU_CGCFGAPB1_PWM1EN_Msk     /*!< Управление тактированием блока PWM1  */
#define RCU_APBClk1_PWM2  RCU_CGCFGAPB1_PWM2EN_Msk     /*!< Управление тактированием блока PWM2  */
#define RCU_APBClk1_PWM3  RCU_CGCFGAPB1_PWM3EN_Msk     /*!< Управление тактированием блока PWM3  */
#define RCU_APBClk1_PWM4  RCU_CGCFGAPB1_PWM4EN_Msk     /*!< Управление тактированием блока PWM4  */
#define RCU_APBClk1_PWM5  RCU_CGCFGAPB1_PWM5EN_Msk     /*!< Управление тактированием блока PWM5  */
#define RCU_APBClk1_PWM6  RCU_CGCFGAPB1_PWM6EN_Msk     /*!< Управление тактированием блока PWM6  */
#define RCU_APBClk1_PWM7  RCU_CGCFGAPB1_PWM7EN_Msk     /*!< Управление тактированием блока PWM7  */
#define RCU_APBClk1_PWM8  RCU_CGCFGAPB1_PWM8EN_Msk     /*!< Управление тактированием блока PWM8  */

#define IS_RCU_APB1_CLK(VALUE)  (((VALUE) == RCU_APBClk1_ACMP0) || \
								 ((VALUE) == RCU_APBClk1_ACMP1) || \
								 ((VALUE) == RCU_APBClk1_ACMP2) || \
								 ((VALUE) == RCU_APBClk1_SDRAM) || \
								 ((VALUE) == RCU_APBClk1_LIN0 ) || \
								 ((VALUE) == RCU_APBClk1_LIN1 ) || \
								 ((VALUE) == RCU_APBClk1_LIN2 ) || \
								 ((VALUE) == RCU_APBClk1_LIN3 ) || \
								 ((VALUE) == RCU_APBClk1_SPI0 ) || \
								 ((VALUE) == RCU_APBClk1_SPI1 ) || \
								 ((VALUE) == RCU_APBClk1_SPI2 ) || \
								 ((VALUE) == RCU_APBClk1_SPI3 ) || \
								 ((VALUE) == RCU_APBClk1_I2C0 ) || \
								 ((VALUE) == RCU_APBClk1_I2C1 ) || \
								 ((VALUE) == RCU_APBClk1_QEP0 ) || \
								 ((VALUE) == RCU_APBClk1_QEP1 ) || \
								 ((VALUE) == RCU_APBClk1_UART0) || \
								 ((VALUE) == RCU_APBClk1_UART1) || \
								 ((VALUE) == RCU_APBClk1_UART2) || \
								 ((VALUE) == RCU_APBClk1_UART3) || \
								 ((VALUE) == RCU_APBClk1_UART4) || \
								 ((VALUE) == RCU_APBClk1_UART5) || \
								 ((VALUE) == RCU_APBClk1_ETH  ) || \
								 ((VALUE) == RCU_APBClk1_PWM0 ) || \
								 ((VALUE) == RCU_APBClk1_PWM1 ) || \
								 ((VALUE) == RCU_APBClk1_PWM2 ) || \
								 ((VALUE) == RCU_APBClk1_PWM3 ) || \
								 ((VALUE) == RCU_APBClk1_PWM4 ) || \
								 ((VALUE) == RCU_APBClk1_PWM5 ) || \
								 ((VALUE) == RCU_APBClk1_PWM6 ) || \
								 ((VALUE) == RCU_APBClk1_PWM7 ) || \
                                 ((VALUE) == RCU_APBClk1_PWM8))

/**
  * @}
  */

/** @defgroup RCU_AHBRst_Define Управление сбросом периферийных блоков AHB
 * @{
 */

#define RCU_AHBRst_GPIOA    RCU_RSTDISAHB_GPIOAEN_Msk   /*!< Управление сбросом блока GPIOA */
#define RCU_AHBRst_GPIOB    RCU_RSTDISAHB_GPIOBEN_Msk   /*!< Управление сбросом блока GPIOB */
#define RCU_AHBRst_GPIOC    RCU_RSTDISAHB_GPIOCEN_Msk   /*!< Управление сбросом блока GPIOC */
#define RCU_AHBRst_GPIOD    RCU_RSTDISAHB_GPIODEN_Msk   /*!< Управление сбросом блока GPIOD */
#define RCU_AHBRst_GPIOE    RCU_RSTDISAHB_GPIOEEN_Msk   /*!< Управление сбросом блока GPIOE */
#define RCU_AHBRst_GPIOF    RCU_RSTDISAHB_GPIOFEN_Msk   /*!< Управление сбросом блока GPIOF */
#define RCU_AHBRst_GPIOG    RCU_RSTDISAHB_GPIOGEN_Msk   /*!< Управление сбросом блока GPIOG */
#define RCU_AHBRst_GPIOH    RCU_RSTDISAHB_GPIOHEN_Msk   /*!< Управление сбросом блока GPIOH */
#define RCU_AHBRst_CAN      RCU_RSTDISAHB_CANEN_Msk     /*!< Управление сбросом блока CAN */
#define RCU_AHBRst_ADC      RCU_RSTDISAHB_ADCEN_Msk     /*!< Управление сбросом блока ADC */
#define RCU_AHBRst_QSPI     RCU_RSTDISAHB_QSPIEN_Msk    /*!< Управление сбросом блока QSPI */
#define RCU_AHBRst_CRC      RCU_RSTDISAHB_CRCEN_Msk     /*!< Управление сбросом блока CRC */
#define RCU_AHBRst_HASH     RCU_RSTDISAHB_HASHEN_Msk    /*!< Управление сбросом блока HASH */
#define RCU_AHBRst_CRYPTO   RCU_RSTDISAHB_CRYPTOEN_Msk  /*!< Управление сбросом блока CRYPTO */
#define RCU_AHBRst_USBD     RCU_RSTDISAHB_USBDEN_Msk    /*!< Управление сбросом блока USBD */
#define RCU_AHBRst_USBH     RCU_RSTDISAHB_USBHEN_Msk    /*!< Управление сбросом блока USBH */
#define RCU_AHBRst_CANFD0   RCU_RSTDISAHB_CANFD0EN_Msk  /*!< Управление сбросом блока CANFD0 */
#define RCU_AHBRst_CANFD1   RCU_RSTDISAHB_CANFD1EN_Msk  /*!< Управление сбросом блока CANFD1 */

#define IS_RCU_AHB_RST(VALUE)   (((VALUE) == RCU_AHBRst_GPIOA) || \
								 ((VALUE) == RCU_AHBRst_GPIOB) || \
								 ((VALUE) == RCU_AHBRst_GPIOC) || \
								 ((VALUE) == RCU_AHBRst_GPIOD) || \
								 ((VALUE) == RCU_AHBRst_GPIOE) || \
								 ((VALUE) == RCU_AHBRst_GPIOF) || \
								 ((VALUE) == RCU_AHBRst_GPIOG) || \
								 ((VALUE) == RCU_AHBRst_GPIOH) || \
								 ((VALUE) == RCU_AHBRst_CAN  ) || \
								 ((VALUE) == RCU_AHBRst_ADC  ) || \
								 ((VALUE) == RCU_AHBRst_QSPI ) || \
								 ((VALUE) == RCU_AHBRst_CRC  ) || \
								 ((VALUE) == RCU_AHBRst_HASH ) || \
								 ((VALUE) == RCU_AHBRst_CRYPTO) || \
								 ((VALUE) == RCU_AHBRst_USBD  ) || \
								 ((VALUE) == RCU_AHBRst_USBH  ) || \
								 ((VALUE) == RCU_AHBRst_CANFD0) || \
                                 ((VALUE) == RCU_AHBRst_CANFD1))

/**
 * @}
 */

/** @defgroup RCU_APBRst_Define Управление сбросом периферийных блоков APB 0
  * @{
  */

#define RCU_APBRst0_DMA   RCU_CGCFGAPB0_DMAEN_Msk      /*!< Управление сбросом блока DMA   */
#define RCU_APBRst0_FLASH RCU_CGCFGAPB0_FLASHEN_Msk    /*!< Управление сбросом блока FLASH */
#define RCU_APBRst0_RAM   RCU_CGCFGAPB0_RAMEN_Msk      /*!< Управление сбросом блока RAM   */
#define RCU_APBRst0_RTC   RCU_CGCFGAPB0_RTCEN_Msk      /*!< Управление сбросом блока RTC   */
#define RCU_APBRst0_WDT   RCU_CGCFGAPB0_WDTEN_Msk      /*!< Управление сбросом блока WDT   */
#define RCU_APBRst0_TRNG  RCU_CGCFGAPB0_TRNGEN_Msk     /*!< Управление сбросом блока TRNG  */
#define RCU_APBRst0_EMC   RCU_CGCFGAPB0_EMCEN_Msk      /*!< Управление сбросом блока EMC   */
#define RCU_APBRst0_CAP0  RCU_CGCFGAPB0_CAP0EN_Msk     /*!< Управление сбросом блока CAP0  */
#define RCU_APBRst0_CAP1  RCU_CGCFGAPB0_CAP1EN_Msk     /*!< Управление сбросом блока CAP1  */
#define RCU_APBRst0_CAP2  RCU_CGCFGAPB0_CAP2EN_Msk     /*!< Управление сбросом блока CAP2  */
#define RCU_APBRst0_CAP3  RCU_CGCFGAPB0_CAP3EN_Msk     /*!< Управление сбросом блока CAP3  */
#define RCU_APBRst0_CAP4  RCU_CGCFGAPB0_CAP4EN_Msk     /*!< Управление сбросом блока CAP4  */
#define RCU_APBRst0_CAP5  RCU_CGCFGAPB0_CAP5EN_Msk     /*!< Управление сбросом блока CAP5  */
#define RCU_APBRst0_DAC0  RCU_CGCFGAPB0_DAC0EN_Msk     /*!< Управление сбросом блока DAC0  */
#define RCU_APBRst0_DAC1  RCU_CGCFGAPB0_DAC1EN_Msk     /*!< Управление сбросом блока DAC1  */
#define RCU_APBRst0_TMR0  RCU_CGCFGAPB0_TMR0EN_Msk     /*!< Управление сбросом блока TMR0  */
#define RCU_APBRst0_TMR1  RCU_CGCFGAPB0_TMR1EN_Msk     /*!< Управление сбросом блока TMR1  */
#define RCU_APBRst0_TMR2  RCU_CGCFGAPB0_TMR2EN_Msk     /*!< Управление сбросом блока TMR2  */
#define RCU_APBRst0_TMR3  RCU_CGCFGAPB0_TMR3EN_Msk     /*!< Управление сбросом блока TMR3  */
#define RCU_APBRst0_TMR4  RCU_CGCFGAPB0_TMR4EN_Msk     /*!< Управление сбросом блока TMR4  */
#define RCU_APBRst0_TMR5  RCU_CGCFGAPB0_TMR5EN_Msk     /*!< Управление сбросом блока TMR5  */
#define RCU_APBRst0_TMR6  RCU_CGCFGAPB0_TMR6EN_Msk     /*!< Управление сбросом блока TMR6  */
#define RCU_APBRst0_TMR7  RCU_CGCFGAPB0_TMR7EN_Msk     /*!< Управление сбросом блока TMR7  */
#define RCU_APBRst0_TMR8  RCU_CGCFGAPB0_TMR8EN_Msk     /*!< Управление сбросом блока TMR8  */
#define RCU_APBRst0_TMR9  RCU_CGCFGAPB0_TMR9EN_Msk     /*!< Управление сбросом блока TMR9  */
#define RCU_APBRst0_TMR10 RCU_CGCFGAPB0_TMR10EN_Msk    /*!< Управление сбросом блока TMR10 */
#define RCU_APBRst0_TMR11 RCU_CGCFGAPB0_TMR11EN_Msk    /*!< Управление сбросом блока TMR11 */
#define RCU_APBRst0_TMR12 RCU_CGCFGAPB0_TMR12EN_Msk    /*!< Управление сбросом блока TMR12 */
#define RCU_APBRst0_TMR13 RCU_CGCFGAPB0_TMR13EN_Msk    /*!< Управление сбросом блока TMR13 */
#define RCU_APBRst0_TMR14 RCU_CGCFGAPB0_TMR14EN_Msk    /*!< Управление сбросом блока TMR14 */
#define RCU_APBRst0_TMR15 RCU_CGCFGAPB0_TMR15EN_Msk    /*!< Управление сбросом блока TMR15 */

#define IS_RCU_APB0_RST(VALUE)   (((VALUE) == RCU_APBRst0_FLASH) || \
								  ((VALUE) == RCU_APBRst0_RAM  ) || \
								  ((VALUE) == RCU_APBRst0_RTC  ) || \
								  ((VALUE) == RCU_APBRst0_WDT  ) || \
								  ((VALUE) == RCU_APBRst0_TRNG ) || \
								  ((VALUE) == RCU_APBRst0_EMC  ) || \
								  ((VALUE) == RCU_APBRst0_CAP0 ) || \
								  ((VALUE) == RCU_APBRst0_CAP1 ) || \
								  ((VALUE) == RCU_APBRst0_CAP2 ) || \
								  ((VALUE) == RCU_APBRst0_CAP3 ) || \
								  ((VALUE) == RCU_APBRst0_CAP4 ) || \
								  ((VALUE) == RCU_APBRst0_CAP5 ) || \
								  ((VALUE) == RCU_APBRst0_DAC0 ) || \
								  ((VALUE) == RCU_APBRst0_DAC1 ) || \
								  ((VALUE) == RCU_APBRst0_TMR0 ) || \
								  ((VALUE) == RCU_APBRst0_TMR1 ) || \
								  ((VALUE) == RCU_APBRst0_TMR2 ) || \
								  ((VALUE) == RCU_APBRst0_TMR3 ) || \
								  ((VALUE) == RCU_APBRst0_TMR4 ) || \
								  ((VALUE) == RCU_APBRst0_TMR5 ) || \
								  ((VALUE) == RCU_APBRst0_TMR6 ) || \
								  ((VALUE) == RCU_APBRst0_TMR7 ) || \
								  ((VALUE) == RCU_APBRst0_TMR8 ) || \
								  ((VALUE) == RCU_APBRst0_TMR9 ) || \
								  ((VALUE) == RCU_APBRst0_TMR10) || \
								  ((VALUE) == RCU_APBRst0_TMR11) || \
								  ((VALUE) == RCU_APBRst0_TMR12) || \
								  ((VALUE) == RCU_APBRst0_TMR13) || \
								  ((VALUE) == RCU_APBRst0_TMR14) || \
								  ((VALUE) == RCU_APBRst0_TMR15))

/**
  * @}
  */

/** @defgroup RCU_APBRst_Define Управление сбросом периферийных блоков APB 1
  * @{
  */

#define RCU_APBRst1_ACMP0 RCU_CGCFGAPB1_ACMP0EN_Msk    /*!< Управление сбросом блока ACMP0 */
#define RCU_APBRst1_ACMP1 RCU_CGCFGAPB1_ACMP1EN_Msk    /*!< Управление сбросом блока ACMP1 */
#define RCU_APBRst1_ACMP2 RCU_CGCFGAPB1_ACMP2EN_Msk    /*!< Управление сбросом блока ACMP2 */
#define RCU_APBRst1_SDRAM RCU_CGCFGAPB1_SDRAMEN_Msk    /*!< Управление сбросом блока SDRAM */
#define RCU_APBRst1_LIN0  RCU_CGCFGAPB1_LIN0EN_Msk     /*!< Управление сбросом блока LIN0  */
#define RCU_APBRst1_LIN1  RCU_CGCFGAPB1_LIN1EN_Msk     /*!< Управление сбросом блока LIN1  */
#define RCU_APBRst1_LIN2  RCU_CGCFGAPB1_LIN2EN_Msk     /*!< Управление сбросом блока LIN2  */
#define RCU_APBRst1_LIN3  RCU_CGCFGAPB1_LIN3EN_Msk     /*!< Управление сбросом блока LIN3  */
#define RCU_APBRst1_SPI0  RCU_CGCFGAPB1_SPI0EN_Msk     /*!< Управление сбросом блока SPI0  */
#define RCU_APBRst1_SPI1  RCU_CGCFGAPB1_SPI1EN_Msk     /*!< Управление сбросом блока SPI1  */
#define RCU_APBRst1_SPI2  RCU_CGCFGAPB1_SPI2EN_Msk     /*!< Управление сбросом блока SPI2  */
#define RCU_APBRst1_SPI3  RCU_CGCFGAPB1_SPI3EN_Msk     /*!< Управление сбросом блока SPI3  */
#define RCU_APBRst1_I2C0  RCU_CGCFGAPB1_I2C0EN_Msk     /*!< Управление сбросом блока I2C0  */
#define RCU_APBRst1_I2C1  RCU_CGCFGAPB1_I2C1EN_Msk     /*!< Управление сбросом блока I2C1  */
#define RCU_APBRst1_QEP0  RCU_CGCFGAPB1_QEP0EN_Msk     /*!< Управление сбросом блока QEP0  */
#define RCU_APBRst1_QEP1  RCU_CGCFGAPB1_QEP1EN_Msk     /*!< Управление сбросом блока QEP1  */
#define RCU_APBRst1_UART0 RCU_CGCFGAPB1_UART0EN_Msk    /*!< Управление сбросом блока UART0 */
#define RCU_APBRst1_UART1 RCU_CGCFGAPB1_UART1EN_Msk    /*!< Управление сбросом блока UART1 */
#define RCU_APBRst1_UART2 RCU_CGCFGAPB1_UART2EN_Msk    /*!< Управление сбросом блока UART2 */
#define RCU_APBRst1_UART3 RCU_CGCFGAPB1_UART3EN_Msk    /*!< Управление сбросом блока UART3 */
#define RCU_APBRst1_UART4 RCU_CGCFGAPB1_UART4EN_Msk    /*!< Управление сбросом блока UART4 */
#define RCU_APBRst1_UART5 RCU_CGCFGAPB1_UART5EN_Msk    /*!< Управление сбросом блока UART5 */
#define RCU_APBRst1_ETH   RCU_CGCFGAPB1_ETHEN_Msk      /*!< Управление сбросом блока ETH   */
#define RCU_APBRst1_PWM0  RCU_CGCFGAPB1_PWM0EN_Msk     /*!< Управление сбросом блока PWM0  */
#define RCU_APBRst1_PWM1  RCU_CGCFGAPB1_PWM1EN_Msk     /*!< Управление сбросом блока PWM1  */
#define RCU_APBRst1_PWM2  RCU_CGCFGAPB1_PWM2EN_Msk     /*!< Управление сбросом блока PWM2  */
#define RCU_APBRst1_PWM3  RCU_CGCFGAPB1_PWM3EN_Msk     /*!< Управление сбросом блока PWM3  */
#define RCU_APBRst1_PWM4  RCU_CGCFGAPB1_PWM4EN_Msk     /*!< Управление сбросом блока PWM4  */
#define RCU_APBRst1_PWM5  RCU_CGCFGAPB1_PWM5EN_Msk     /*!< Управление сбросом блока PWM5  */
#define RCU_APBRst1_PWM6  RCU_CGCFGAPB1_PWM6EN_Msk     /*!< Управление сбросом блока PWM6  */
#define RCU_APBRst1_PWM7  RCU_CGCFGAPB1_PWM7EN_Msk     /*!< Управление сбросом блока PWM7  */
#define RCU_APBRst1_PWM8  RCU_CGCFGAPB1_PWM8EN_Msk     /*!< Управление сбросом блока PWM8  */

#define IS_RCU_APB1_RST(VALUE)  (((VALUE) == RCU_APB1Rst_ACMP0) || \
								 ((VALUE) == RCU_APBRst1_ACMP1) || \
								 ((VALUE) == RCU_APBRst1_ACMP2) || \
								 ((VALUE) == RCU_APBRst1_SDRAM) || \
								 ((VALUE) == RCU_APBRst1_LIN0 ) || \
								 ((VALUE) == RCU_APBRst1_LIN1 ) || \
								 ((VALUE) == RCU_APBRst1_LIN2 ) || \
								 ((VALUE) == RCU_APBRst1_LIN3 ) || \
								 ((VALUE) == RCU_APBRst1_SPI0 ) || \
								 ((VALUE) == RCU_APBRst1_SPI1 ) || \
								 ((VALUE) == RCU_APBRst1_SPI2 ) || \
								 ((VALUE) == RCU_APBRst1_SPI3 ) || \
								 ((VALUE) == RCU_APBRst1_I2C0 ) || \
								 ((VALUE) == RCU_APBRst1_I2C1 ) || \
								 ((VALUE) == RCU_APBRst1_QEP0 ) || \
								 ((VALUE) == RCU_APBRst1_QEP1 ) || \
								 ((VALUE) == RCU_APBRst1_UART0) || \
								 ((VALUE) == RCU_APBRst1_UART1) || \
								 ((VALUE) == RCU_APBRst1_UART2) || \
								 ((VALUE) == RCU_APBRst1_UART3) || \
								 ((VALUE) == RCU_APBRst1_UART4) || \
								 ((VALUE) == RCU_APBRst1_UART5) || \
								 ((VALUE) == RCU_APBRst1_ETH  ) || \
								 ((VALUE) == RCU_APBRst1_PWM0 ) || \
								 ((VALUE) == RCU_APBRst1_PWM1 ) || \
								 ((VALUE) == RCU_APBRst1_PWM2 ) || \
								 ((VALUE) == RCU_APBRst1_PWM3 ) || \
								 ((VALUE) == RCU_APBRst1_PWM4 ) || \
								 ((VALUE) == RCU_APBRst1_PWM5 ) || \
								 ((VALUE) == RCU_APBRst1_PWM6 ) || \
								 ((VALUE) == RCU_APBRst1_PWM7 ) || \
                                 ((VALUE) == RCU_APBRst1_PWM8))

/**
  * @}
  */

/**
  * @}
  */

/** @defgroup RCU_Exported_Types Типы
  * @{
  */

/**
  * @brief  Выбор PLL (0,1,2)
  */
typedef enum {
    RCU_PLL0 = 0,       /*!< PLL0 */
	RCU_PLL1 = 1,       /*!< PLL1 */
	RCU_PLL2 = 2,       /*!< PLL2 */
} RCU_PLL_TypeDef;
#define IS_RCU_PLL(VALUE) (((VALUE) == RCU_PLL0) ||    \
                           ((VALUE) == RCU_PLL1) ||    \
                           ((VALUE) == RCU_PLL2))

/**
  * @brief  Выбор источника тактирования для периферийного блока
  *         c несколькими тактовыми доменами - UART, QSPI, SPI, WDT, ADCSAR, ADCSD
  */
typedef enum {
    RCU_PeriphClk_HsiClk = RCU_UARTCFG_CLKSEL_HSICLK,       /*!< Сигнал HSICLK */
    RCU_PeriphClk_HseClk = RCU_UARTCFG_CLKSEL_HSECLK,       /*!< Сигнал HSCLK */
    RCU_PeriphClk_PllClk = RCU_UARTCFG_CLKSEL_PLL0CLK,       /*!< Сигнал PLLCLK */
    RCU_PeriphClk_ExtClk = RCU_UARTCFG_CLKSEL_EXTCLK        /*!< Сигнал EXTCLK */
} RCU_PeriphClk_TypeDef;
#define IS_RCU_PERIPH_CLK(VALUE) (((VALUE) == RCU_PeriphClk_HsiClk) ||    \
                                  ((VALUE) == RCU_PeriphClk_HsClk) ||    \
                                  ((VALUE) == RCU_PeriphClk_PllClk) || \
                                  ((VALUE) == RCU_PeriphClk_ExtClk))

/**
  * @brief  Выбор источника тактирования для CLKOUT
  */
typedef enum {
    RCU_ClkoutClk_HsiClk = RCU_CLKOUTCFG_CLKSEL_HSICLK,      /*!< Сигнал HSICLK */
    RCU_ClkoutClk_HseClk = RCU_CLKOUTCFG_CLKSEL_HSECLK,      /*!< Сигнал HSECLK */
    RCU_ClkoutClk_PLLClk = RCU_CLKOUTCFG_CLKSEL_PLL0CLK,      /*!< Сигнал SYSPLL0CL */
    RCU_ClkoutClk_RTCClk = RCU_CLKOUTCFG_CLKSEL_RTCCLK       /*!< Сигнал RTCCLK */
} RCU_ClkoutClk_TypeDef;
#define IS_RCU_SPWR_CLK(VALUE) (((VALUE) == RCU_ClkoutClk_HsiClk) ||    \
                                ((VALUE) == RCU_ClkoutClk_HseClk) ||    \
                                ((VALUE) == RCU_ClkoutClk_SysPLL0Clk) || \
                                ((VALUE) == RCU_ClkoutClk_LsiClk))

/**
  * @brief  Выбор источника системной частоты
  */
typedef enum {
    RCU_SysClk_HsiClk = RCU_SYSCLKCFG_SRC_HSICLK,     /*!< Сигнал HSICLK */
    RCU_SysClk_HseClk = RCU_SYSCLKCFG_SRC_HSECLK,     /*!< Сигнал HSECLK */
    RCU_SysClk_PLLClk = RCU_SYSCLKCFG_SRC_PLL0CLK,     /*!< Сигнал SYSPLL0CLK */
    RCU_SysClk_ExtClk = RCU_SYSCLKCFG_SRC_EXTCLK      /*!< Сигнал LSICLK */
} RCU_SysClk_TypeDef;
#define IS_RCU_SYS_CLK(VALUE) (((VALUE) == RCU_SysClk_HsiClk) || \
                               ((VALUE) == RCU_SysClk_HseClk) || \
                               ((VALUE) == RCU_SysClk_PLLClk) || \
                               ((VALUE) == RCU_SysClk_ExtClk))

/**
  * @brief  Структура инициализации PLL
  *
  */
typedef struct
{
    uint32_t RDiv;               /*!< Делитель опорного сигнала PLL (M).
                                   Параметр может принимать любое значение из диапазона 1-63. */
    uint32_t NDiv;               /*!< Делитель опорного сигнала PLL (M).
                                   Параметр может принимать любое значение из диапазона 1-63. */
    uint32_t PreDiv;            /*!< Делитель опорного сигнала PLL (M).
                                   Параметр может принимать любое значение из диапазона 1-63. */
    uint32_t FbDiv;           	/*!< Делитель обратной связи (N).
                                   Параметр может принимать любое значение из диапазона:
                                      16-160 (без дробного делителя),
                                      20-160 (с дробным делителем) */
    uint32_t FracDiv;         /*!< Дробный делитель.
                                   Параметр может принимать любое значение из диапазона 1-255. */                                   
    uint32_t DivA;           /*!< Внутренний делитель PLL A (итоговое значение (DivA+1))
                                   Параметр может принимать любое значение из диапазона 0-7. */
    uint32_t DivB;           /*!< Внутренний делитель PLL B (итоговое значение (DivB+1))
                                   Параметр может принимать любое значение из диапазона 0-63. */
} RCU_PLL_Init_TypeDef;

#define IS_RCU_PLL_REF_DIV(VALUE) (((VALUE) <= 63) && ((VALUE) >= 1))
#define IS_RCU_PLL_FB_DIV(VALUE) (((VALUE) <= 160) && ((VALUE) >= 16))
#define IS_RCU_PLL_DIVA(VALUE) (((VALUE) <= 7) && ((VALUE) >= 0))
#define IS_RCU_PLL_DIVB(VALUE) (((VALUE) <= 7) && ((VALUE) >= 0))
#define IS_RCU_PLL_DIVA_DIVB(VALUE_A,VALUE_B) (VALUE_A > VALUE_B)
#define IS_RCU_PLL_REF_FREQ(VALUE) (((VALUE) <= 50000000) && ((VALUE) >= 10000000))
#define IS_RCU_PLL_OUT_FREQ(VALUE) (((VALUE) <= 1600000000) && ((VALUE) >= 8000000))
#define IS_RCU_PLL_FVCO_FREQ(VALUE) (((VALUE) <= 1600000000) && ((VALUE) >= 200000000))
#define IS_RCU_PLL_FREF_DIV_FREQ(VALUE) ((VALUE) >= 10000000)
#define IS_RCU_SYSCLK_FREQ(VALUE) (((VALUE) <= 60000000) && ((VALUE) >= 1000000))
#define IS_RCU_SECPRD(VALUE) (((VALUE)&0xFFFFFF00) == 0)
#define IS_RCU_PERIPH_DIV(VALUE) (((VALUE)&0xFFFFFFC0) == 0)
#define IS_RCU_CLKOUT_DIV(VALUE) (((VALUE)&0xFFFFFFF8) == 0)

/**
  * @}
  */

/** @defgroup RCU_Exported_Functions Функции
  * @{
  */

uint32_t RCU_GetHsiClkFreq(void);
uint32_t RCU_GetHseClkFreq(void);
uint32_t RCU_GetExtClkFreq(void);
uint32_t RCU_GetRTCClkFreq(void);
uint32_t RCU_GetPLLClkFreq(RCU_PLL_TypeDef PllNum);

/**
  * @brief   Включение тактирования выбранного APB блока периферии
  * 		 Группа 0: DMA, FLASH, RAM, RTC, WDT, TRNG, EMC, CAP, DAC, TMR.
  * @param   APBClk  Выбор периферии. Любая совокупность значений значений RCU_APB0Clk_x (@ref RCU_APB0Clk_Define).
  * @param   State  Выбор состояния
  * @retval  void
  */
__STATIC_INLINE void RCU_APBClk0Cmd(uint32_t APBClk, FunctionalState State)
{
    assert_param(IS_RCU_APB0_CLK(APBClk));
    assert_param(IS_FUNCTIONAL_STATE(State));

    MODIFY_REG(RCU->CGCFGAPB0, APBClk, State ? APBClk : 0);
}

/**
  * @brief   Включение тактирования выбранного APB блока периферии
  * 		 Группа 1: ACMP, SDRAM, LIN, SPI, I2C, QEP, UART, ETH, PWM.
  * @param   APBClk  Выбор периферии. Любая совокупность значений значений RCU_APB1Clk_x (@ref RCU_APB1Clk_Define).
  * @param   State  Выбор состояния
  * @retval  void
  */
__STATIC_INLINE void RCU_APBClk1Cmd(uint32_t APBClk, FunctionalState State)
{
    assert_param(IS_RCU_APB1_CLK(APBClk));
    assert_param(IS_FUNCTIONAL_STATE(State));

    MODIFY_REG(RCU->CGCFGAPB1, APBClk, State ? APBClk : 0);
}

/**
  * @brief   Включение тактирования выбранного AHB блока периферии.
  * @param   AHBClk  Выбор периферии. Любая совокупность значений значений RCU_AHBClk_x (@ref RCU_AHBClk_Define).
  * @param   State  Выбор состояния
  * @retval  void
  */
__STATIC_INLINE void RCU_AHBClkCmd(uint32_t AHBClk, FunctionalState State)
{
    assert_param(IS_RCU_AHB_CLK(AHBClk));
    assert_param(IS_FUNCTIONAL_STATE(State));

    MODIFY_REG(RCU->CGCFGAHB, AHBClk, State ? AHBClk : 0);
}

/**
  * @brief   Вывод из состояния сброса периферийных блоков APB
  * 		 Группа 0: DMA, FLASH, RAM, RTC, WDT, TRNG, EMC, CAP, DAC, TMR.
  * @param   APBRst  Выбор периферийного модуля. Любая совокупность значений значений RCU_APB0Rst_x (@ref RCU_APB0Rst_Define).
  * @param   State  Выбор состояния
  * @retval  void
  */
__STATIC_INLINE void RCU_APBRst0Cmd(uint32_t APBRst, FunctionalState State)
{
    assert_param(IS_RCU_APB_RST(APBRst));
    assert_param(IS_FUNCTIONAL_STATE(State));

    MODIFY_REG(RCU->RSTDISAPB0, APBRst, State ? APBRst : 0);
}

/**
  * @brief   Вывод из состояния сброса периферийных блоков APB
  * 		 Группа 1: ACMP, SDRAM, LIN, SPI, I2C, QEP, UART, ETH, PWM.
  * @param   APBRst  Выбор периферийного модуля. Любая совокупность значений значений RCU_APB1Rst_x (@ref RCU_APB1Rst_Define).
  * @param   State  Выбор состояния
  * @retval  void
  */
__STATIC_INLINE void RCU_APBRst1Cmd(uint32_t APBRst, FunctionalState State)
{
    assert_param(IS_RCU_APB1_RST(APBRst));
    assert_param(IS_FUNCTIONAL_STATE(State));

    MODIFY_REG(RCU->RSTDISAPB1, APBRst, State ? APBRst : 0);
}

/**
  * @brief   Вывод из состояния сброса периферийных блоков AHB
  * @param   AHBRst  Выбор периферийного модуля. Любая совокупность значений значений RCU_AHBRst_x (@ref RCU_AHBRst_Define).
  * @param   State  Выбор состояния
  * @retval  void
  */
__STATIC_INLINE void RCU_AHBRstCmd(uint32_t AHBRst, FunctionalState State)
{
    assert_param(IS_RCU_AHB_RST(AHBRst));
    assert_param(IS_FUNCTIONAL_STATE(State));

    MODIFY_REG(RCU->RSTDISAHB, AHBRst, State ? AHBRst : 0);
}

/**
  * @brief   Установка опорного тактового сигнала для системной частоты
  * @param   SysClk  Выбор тактового сигнала
  * @retval  void
  */
__STATIC_INLINE void RCU_SysClkConfig(RCU_SysClk_TypeDef SysClk)
{
    assert_param(IS_RCU_SYS_CLK(SysClk));

    WRITE_REG(RCU->SYSCLKCFG_bit.SRC, SysClk);
}

/**
  * @brief   Получение текущего опорного тактового сигнала для системной частоты
  * @retval  Val  Выбранный сигнал
  */
__STATIC_INLINE RCU_SysClk_TypeDef RCU_SysClkStatus(void)
{
    return (RCU_SysClk_TypeDef)READ_REG(RCU->CLKSTAT_bit.SRC);
}

/**
  * @brief   Получение статуса выбранного тактового сигнала
  * @param   ClkStatus  Выбор тактового сигнала. Любая совокупность значений значений RCU_ClkStatus_x (@ref RCU_ClkStatus_Define).
  * @retval  Status  Статус
  */
__STATIC_INLINE FlagStatus RCU_ClkStatus(uint32_t ClkStatus)
{
    return (FlagStatus)READ_BIT(RCU->CLKSTAT, ClkStatus);
}

uint32_t RCU_GetSysClkFreq(void);

/**
  * @brief   Включение системы слежения за системным тактовым сигналом
  * @param   State  Выбор состояния
  * @retval  void
  */
__STATIC_INLINE void RCU_SecurityCmd(FunctionalState State)
{
    assert_param(IS_FUNCTIONAL_STATE(State));

    WRITE_REG(RCU->SYSCLKCFG_bit.SECEN, State);
}

/**
  * @brief   Настройка периода срабатывания системы слежения
  * @param   HsePrd  Максимальное значение счетчика слежения за сигналом HSeCLK
  * @param   PLLPrd  Максимальное значение счетчика слежения за сигналом SYSPLL0CLK
  * @param   LsiPrd  Максимальное значение счетчика слежения за сигналом LSICLK
  * @retval  void
  */
__STATIC_INLINE void RCU_SecurityConfig(uint32_t HsePrd, uint32_t PLLPrd, uint32_t LsiPrd)
{
    assert_param(IS_RCU_SECPRD(HsePrd));
    assert_param(IS_RCU_SECPRD(PLLPrd));
    assert_param(IS_RCU_SECPRD(LsiPrd));

    WRITE_REG(RCU->SECCNT0, (HsePrd << RCU_SECCNT0_VAL1_Pos));
    WRITE_REG(RCU->SECCNT1, (LsiPrd << RCU_SECCNT1_VAL3_Pos)|PLLPrd);
}

/**
  * @brief   Получение статуса выбранного типа сброса
  * @param   RstStatus  Выбранный тип сброса. Любая совокупность значений значений RCU_RstStatus_x (@ref RCU_RstStatus_Define).
  * @retval  Status  Статус активности
  */
__STATIC_INLINE FlagStatus RCU_RstStatus(uint32_t RstStatus)
{
    return (FlagStatus)READ_BIT(RCU->RSTSTAT, RstStatus);
}

/**
  * @brief   Очистка статуса выбранного типа сброса
  * @param   RstStatus  Выбранный тип сброса. Любая совокупность значений значений RCU_RstStatus_x (@ref RCU_RstStatus_Define).
  * @retval  void
  */
__STATIC_INLINE void RCU_RstStatusClear(uint32_t RstStatus)
{
    assert_param(IS_RCU_RST_STATUS(RstStatus));

    WRITE_REG(RCU->RSTSTAT, RstStatus);
}

OperationStatus RCU_SysClkChangeCmd(RCU_SysClk_TypeDef SysClk);

/** @defgroup RCU_Init_Deinit Конфигурация PLL
  * @{
  */

//OperationStatus RCU_PLL_AutoConfig(uint32_t SysClkFreq, RCU_PLL_Ref_TypeDef Ref);
OperationStatus RCU_PLL_Init(RCU_PLL_TypeDef PllNum, RCU_PLL_Init_TypeDef* InitStruct);
void RCU_PLL_DeInit(RCU_PLL_TypeDef PllNum);
void RCU_PLL_StructInit(RCU_PLL_Init_TypeDef* InitStruct);

/**
  * @brief   Разрешение работы выхода PLL
  * @param   PllNum  Выбор PLL
  * @param   State  Выбор состояния
  * @retval  void
  */
__STATIC_INLINE void RCU_PLL_OutCmd(RCU_PLL_TypeDef PllNum, FunctionalState State)
{
    assert_param(IS_FUNCTIONAL_STATE(State));
    assert_param(IS_RCU_PLL(PllNum));

    WRITE_REG(RCU->PLL[PllNum].CFG_bit.FOUTEN, State);
}


/**
  * @brief   Включение режима bypass PLL
  * @param   PllNum  Выбор PLL
  * @param   State  Выбор состояния
  * @retval  void
  */
__STATIC_INLINE void RCU_PLL_BypassCmd(RCU_PLL_TypeDef PllNum, FunctionalState State)
{
    assert_param(IS_FUNCTIONAL_STATE(State));
    assert_param(IS_RCU_PLL(PllNum));

    WRITE_REG(RCU->PLL[PllNum].CFG_bit.BYPASS, State);
}

/**
  * @brief   Получение статуса захвата частоты PLL
  * @param   PllNum  Выбор PLL
  * @retval  Status  Статус захвата
  */
__STATIC_INLINE FlagStatus RCU_PLL_LockStatus(RCU_PLL_TypeDef PllNum)
{
    return (FlagStatus)READ_BIT(RCU->PLLSTAT, (RCU_PLLSTAT_PLL0LOCK_Msk << PllNum));
}


/**
  * @}
  */

/** @defgroup RCU_CLK_Config_ClkOut Настройка выдачи тактового сигнала CLKOUT
  * @{
  */

uint32_t RCU_GetClkOutFreq(void);

/**
  * @brief   Настройка тактирования ClkOut
  * @param   ClkOut  Источник тактового сигнала
  * @param   DivVal  Значение делителя (деление на 2*(DivVal+1))
  * @param   DivState  Разрешение работы делителя
  * @retval  void
  */
__STATIC_INLINE void RCU_ClkOutConfig(RCU_ClkoutClk_TypeDef ClkOut, uint32_t DivVal, FunctionalState DivState)
{
    assert_param(IS_RCU_SYS_PERIPH_CLK(ClkOut));
    assert_param(IS_RCU_PERIPH_DIV(DivVal));
    assert_param(IS_FUNCTIONAL_STATE(DivState));

    MODIFY_REG(RCU->CLKOUTCFG, (RCU_CLKOUTCFG_CLKSEL_Msk | RCU_CLKOUTCFG_DIVN_Msk | RCU_CLKOUTCFG_DIVEN_Msk),
               ((ClkOut << RCU_CLKOUTCFG_CLKSEL_Pos) | (DivVal << RCU_CLKOUTCFG_DIVN_Pos) | (DivState << RCU_CLKOUTCFG_DIVEN_Pos)));
}

/**
  * @brief   Включение тактирования ClkOut
  * @param   State  Выбор состояния
  * @retval  void
  */
__STATIC_INLINE void RCU_ClkOutCmd(FunctionalState State)
{
    assert_param(IS_FUNCTIONAL_STATE(State));

    WRITE_REG(RCU->CLKOUTCFG_bit.CLKEN, State);
}

/**
  * @}
  */

/** @defgroup RCU_CLK_RST_Config_UART Тактирование и сброс UART
  * @{
  */

uint32_t RCU_GetUARTClkFreq(UART_Num_TypeDef UARTx_Num);

/**
  * @brief   Настройка тактирования UART
  * @param   UARTx_Num  Порядковый номер блока UART
  * @param   UARTClk  Источник тактового сигнала
  * @param   DivVal  Значение делителя (деление на 2*(DivVal+1))
  * @param   DivState  Разрешение работы делителя
  * @retval  void
  */
__STATIC_INLINE void RCU_UARTClkConfig(UART_Num_TypeDef UARTx_Num, RCU_PeriphClk_TypeDef UARTClk, uint32_t DivVal, FunctionalState DivState)
{
    assert_param(IS_RCU_PERIPH_CLK(UARTClk));
    assert_param(IS_RCU_PERIPH_DIV(DivVal));
    assert_param(IS_FUNCTIONAL_STATE(DivState));

    MODIFY_REG(RCU->UARTCFG[UARTx_Num].UARTCFG, (RCU_UARTCFG_CLKEN_Msk | RCU_UARTCFG_DIVN_Msk | RCU_UARTCFG_DIVEN_Msk),
               ((UARTClk << RCU_UARTCFG_CLKSEL_Pos) | (DivVal << RCU_UARTCFG_DIVN_Pos) | (DivState << RCU_UARTCFG_DIVEN_Pos)));
}

/**
  * @brief   Включение тактирования UART
  * @param   State  Выбор состояния
  * @retval  void
  */
__STATIC_INLINE void RCU_UARTClkCmd(UART_Num_TypeDef UARTx_Num, FunctionalState State)
{
    assert_param(IS_FUNCTIONAL_STATE(State));

    WRITE_REG(RCU->UARTCFG[UARTx_Num].UARTCFG_bit.CLKEN, State);
}

/**
  * @brief   Cнятие сброса UART
  * @param   UARTx_Num  Порядковый номер блока UART
  * @param   State  Выбор состояния
  * @retval  void
  */
__STATIC_INLINE void RCU_UARTRstCmd(UART_Num_TypeDef UARTx_Num, FunctionalState State)
{
    assert_param(IS_FUNCTIONAL_STATE(State));

    WRITE_REG(RCU->UARTCFG[UARTx_Num].UARTCFG_bit.RSTDIS, State);
}

/**
  * @}
  */

/** @defgroup RCU_CLK_RST_Config_SPI Тактирование и сброс SPI
  * @{
  */

uint32_t RCU_GetSPIClkFreq(SPI_Num_TypeDef SPIx_Num);

/**
  * @brief   Настройка тактирования SPI
  * @param   SPIx_Num  Порядковый номер блока SPI
  * @param   SPIClk  Источник тактового сигнала
  * @param   DivVal  Значение делителя (деление на 2*(DivVal+1))
  * @param   DivState  Разрешение работы делителя
  * @retval  void
  */
__STATIC_INLINE void RCU_SPIClkConfig(SPI_Num_TypeDef SPIx_Num, RCU_PeriphClk_TypeDef SPIClk, uint32_t DivVal, FunctionalState DivState)
{
    assert_param(IS_RCU_PERIPH_CLK(SPIClk));
    assert_param(IS_RCU_PERIPH_DIV(DivVal));
    assert_param(IS_FUNCTIONAL_STATE(DivState));

    MODIFY_REG(RCU->SPICFG[SPIx_Num].SPICFG, (RCU_SPICFG_CLKSEL_Msk | RCU_SPICFG_DIVN_Msk | RCU_SPICFG_DIVEN_Msk),
               ((SPIClk << RCU_SPICFG_CLKSEL_Pos) | (DivVal << RCU_SPICFG_DIVN_Pos) | (DivState << RCU_SPICFG_DIVEN_Pos)));
}

/**
  * @brief   Включение тактирования SPI
  * @param   SPIx_Num  Порядковый номер блока SPI
  * @param   State  Выбор состояния
  * @retval  void
  */
__STATIC_INLINE void RCU_SPIClkCmd(SPI_Num_TypeDef SPIx_Num, FunctionalState State)
{
    assert_param(IS_FUNCTIONAL_STATE(State));

    WRITE_REG(RCU->SPICFG[SPIx_Num].SPICFG_bit.CLKEN, State);
}

/**
  * @brief   Cнятие сброса SPI
  * @param   SPIx_Num  Порядковый номер блока SPI
  * @param   State  Выбор состояния
  * @retval  void
  */
__STATIC_INLINE void RCU_SPIRstCmd(SPI_Num_TypeDef SPIx_Num, FunctionalState State)
{
    assert_param(IS_FUNCTIONAL_STATE(State));

    WRITE_REG(RCU->SPICFG[SPIx_Num].SPICFG_bit.RSTDIS, State);
}

/**
  * @}
  */

/** @defgroup RCU_CLK_RST_Config_WDT Тактирование и сброс WDT
  * @{
  */

uint32_t RCU_GetWDTClkFreq(void);

/**
  * @brief   Настройка тактирования сторожевого таймера
  * @param   WDTClk  Источник тактового сигнала
  * @param   DivVal  Значение делителя (деление на 2*(DivVal+1))
  * @param   DivState  Разрешение работы делителя
  * @retval  void
  */
__STATIC_INLINE void RCU_WDTClkConfig(RCU_PeriphClk_TypeDef WDTClk, uint32_t DivVal, FunctionalState DivState)
{
    assert_param(IS_RCU_SYS_PERIPH_CLK(WDTClk));
    assert_param(IS_RCU_PERIPH_DIV(DivVal));
    assert_param(IS_FUNCTIONAL_STATE(DivState));

    MODIFY_REG(RCU->WDTCFG, (RCU_WDTCFG_CLKSEL_Msk | RCU_WDTCFG_DIVN_Msk | RCU_WDTCFG_DIVEN_Msk),
               ((WDTClk << RCU_WDTCFG_CLKSEL_Pos) | (DivVal << RCU_WDTCFG_DIVN_Pos) | (DivState << RCU_WDTCFG_DIVEN_Pos)));
}

/**
  * @brief   Включение тактирования сторожевого таймера
  * @param   State  Выбор состояния
  * @retval  void
  */
__STATIC_INLINE void RCU_WDTClkCmd(FunctionalState State)
{
    assert_param(IS_FUNCTIONAL_STATE(State));

    WRITE_REG(RCU->WDTCFG_bit.CLKEN, State);
}

/**
  * @brief   Cнятие сброса сторожевого таймера
  * @param   State  Выбор состояния
  * @retval  void
  */
__STATIC_INLINE void RCU_WDTRstCmd(FunctionalState State)
{
    assert_param(IS_FUNCTIONAL_STATE(State));

    WRITE_REG(RCU->WDTCFG_bit.RSTDIS, State);
}

/**
  * @}
  */

/** @defgroup RCU_CLK_RST_Config_ADC Тактирование и сброс ADC
  * @{
  */

uint32_t RCU_GetADCClkFreq(void);

/**
  * @brief   Настройка тактирования АЦП
  * @param   ADCClk  Источник тактового сигнала
  * @param   DivVal  Значение делителя (деление на 2*(DivVal+1))
  * @param   DivState  Разрешение работы делителя
  * @retval  void
  */
__STATIC_INLINE void RCU_ADCClkConfig(RCU_PeriphClk_TypeDef ADCClk, uint32_t DivVal, FunctionalState DivState)
{
    assert_param(IS_RCU_PERIPH_CLK(ADCClk));
    assert_param(IS_RCU_PERIPH_DIV(DivVal));
    assert_param(IS_FUNCTIONAL_STATE(DivState));

    MODIFY_REG(RCU->ADCCFG, (RCU_ADCCFG_CLKSEL_Msk | RCU_ADCCFG_DIVN_Msk | RCU_ADCCFG_DIVEN_Msk),
               ((ADCClk << RCU_ADCCFG_CLKSEL_Pos) | (DivVal << RCU_ADCCFG_DIVN_Pos) | (DivState << RCU_ADCCFG_DIVEN_Pos)));
}

/**
  * @brief   Включение тактирования АЦП
  * @param   State  Выбор состояния
  * @retval  void
  */
__STATIC_INLINE void RCU_ADCSARClkCmd(FunctionalState State)
{
    assert_param(IS_FUNCTIONAL_STATE(State));

    WRITE_REG(RCU->ADCCFG_bit.CLKEN, State);
}

/**
  * @brief   Cнятие сброса АЦП
  * @param   State  Выбор состояния
  * @retval  void
  */
__STATIC_INLINE void RCU_ADCSARRstCmd(FunctionalState State)
{
    assert_param(IS_FUNCTIONAL_STATE(State));

    WRITE_REG(RCU->ADCCFG_bit.RSTDIS, State);
}

/**
  * @}
  */

/**
  * @}
  */

#ifdef __cplusplus
}
#endif

#endif /* __PLIB3T_RCU_H */

/**
  * @}
  */

/**
  * @}
  */

/******************* (C) COPYRIGHT 2025 NIIET *****END OF FILE****/
