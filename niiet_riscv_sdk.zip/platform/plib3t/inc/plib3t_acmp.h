/**
  ******************************************************************************
  * @file    plib3t_acmp.h
  *
  * @brief   Файл содержит прототипы и компактные inline реализации функций для
  *          ACMP, а также сопутствующие макроопределения и перечисления
  *
  * @author  НИИЭТ, Александр Дыхно <dykhno@niiet.ru>
  * @author  НИИЭТ, Штоколов Филипп
  *
  ******************************************************************************
  * @attention
  *
  * ДАННОЕ ПРОГРАММНОЕ ОБЕСПЕЧЕНИЕ ПРЕДОСТАВЛЯЕТСЯ «КАК ЕСТЬ», БЕЗ КАКИХ-ЛИБО
  * ГАРАНТИЙ, ЯВНО ВЫРАЖЕННЫХ ИЛИ ПОДРАЗУМЕВАЕМЫХ, ВКЛЮЧАЯ ГАРАНТИИ ТОВАРНОЙ
  * ПРИГОДНОСТИ, СООТВЕТСТВИЯ ПО ЕГО КОНКРЕТНОМУ НАЗНАЧЕНИЮ И ОТСУТСТВИЯ
  * НАРУШЕНИЙ, НО НЕ ОГРАНИЧИВАЯСЬ ИМИ. ДАННОЕ ПРОГРАММНОЕ ОБЕСПЕЧЕНИЕ
  * ПРЕДНАЗНАЧЕНО ДЛЯ ОЗНАКОМИТЕЛЬНЫХ ЦЕЛЕЙ И НАПРАВЛЕНО ТОЛЬКО НА
  * ПРЕДОСТАВЛЕНИЕ ДОПОЛНИТЕЛЬНОЙ ИНФОРМАЦИИ О ПРОДУКТЕ, С ЦЕЛЬЮ СОХРАНИТЬ ВРЕМЯ
  * ПОТРЕБИТЕЛЮ. НИ В КАКОМ СЛУЧАЕ АВТОРЫ ИЛИ ПРАВООБЛАДАТЕЛИ НЕ НЕСУТ
  * ОТВЕТСТВЕННОСТИ ПО КАКИМ-ЛИБО ИСКАМ, ЗА ПРЯМОЙ ИЛИ КОСВЕННЫЙ УЩЕРБ, ИЛИ
  * ПО ИНЫМ ТРЕБОВАНИЯМ, ВОЗНИКШИМ ИЗ-ЗА ИСПОЛЬЗОВАНИЯ ПРОГРАММНОГО ОБЕСПЕЧЕНИЯ
  * ИЛИ ИНЫХ ДЕЙСТВИЙ С ПРОГРАММНЫМ ОБЕСПЕЧЕНИЕМ.
  *
  * <h2><center>&copy; 2025 АО "НИИЭТ"</center></h2>
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __PLIB3T_ACMP_H
#define __PLIB3T_ACMP_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "plib3t.h"

/** @addtogroup Peripheral
  * @{
  */

/** @defgroup ACMP
  * @brief Драйвер для работы с ACMP
  * @{
  */

/** @defgroup ACMP_Exported_Defines Константы
  * @{
  */

/** @defgroup ACMP_ITSource_Define Источники прерываний ACMP
  * @{
  */

/**
   * @}
   */

/** @defgroup ACMP_Flag_Define Флаги работы ACMP
  * @{
  */


/**
  * @}
  */

/**
  * @}
  */

/** @defgroup ACMP_Exported_Types Типы
  * @{
  */

#define ACMP_DAC_REF0 0x0
#define ACMP_DAC_REF1 0x8
#define IS_CMP_DAC_REF(VALUE) (((VALUE) == ACMP_REF0) || \
							((VALUE) == ACMP_REF1))

/**
  * @brief  Выбор сигнала для отрицательного входа компаратора ACMPx
  */
typedef enum {
	ACMP_Ref_Inx = 0x0,	/*!< Вывод микроконтроллера для соответствующего ACMPx */
	ACMP_Ref_DAC0 = 0x1,	/*!< Выход ЦАП REF0 */
	ACMP_Ref_DAC1 = 0x2	/*!< ВЫХОД ЦАП REF1 */
} ACMP_Ref_TypeDef;
#define IS_CMP_REF(VALUE) (((VALUE) == ACMP_Ref_Inx) || \
							((VALUE) == ACMP_DAC0) || \
							((VALUE) == ACMP_DAC1))

/**
  * @brief  Выбор события для реагирования, используется как событие формирования прерывания или как событие
  * 		пробуждения микроконтроллера
  */
typedef enum {
	ACMP_Event_No = 0x0,			/*!< Нет события, на которое должна последовать реакция*/
	ACMP_Event_RiseEdge = 0x1,	/*!< Положительный фронт */
	ACMP_Event_FallEdge = 0x2,	/*!< Отрицательный фронт */
	ACMP_Event_AnyEdge = 0x3,	/*!< Любой фронт */
	ACMP_Event_High = 0x4,		/*!< Уровень логической единицы */
	ACMP_Event_Low = 0x5			/*!< Уровень логического нуля */
} ACMP_Event_TypeDef;
#define IS_CMP_EVENT(VALUE) (((VALUE) == ACMP_Event_No) || \
							((VALUE) == ACMP_Event_RiseEdge) || \
							((VALUE) == ACMP_Event_FallEdge) || \
							((VALUE) == ACMP_Event_AnyEdge) || \
							((VALUE) == ACMP_Event_High) || \
							((VALUE) == ACMP_Event_Low))

#define IS_CMP_REFVAL(VALUE) ((VALUE) < 0x10)

/**
  * @}
  */

/** @defgroup ACMP_Exported_Functions Функции
  * @{
  */

/**
  * @brief   Разрешение работы ЦАП компаратора ACMP
  * @param   ACMPx  Выбор блока ACMP, где x лежит в диапазоне 0-2.
  * @param   State  Выбор состояния
  * @retval  void
  */
__STATIC_INLINE void ACMP_DAC_Cmd(ACMP_TypeDef* ACMPx, FunctionalState State)
{
    assert_param(IS_ACMP_PERIPH(ACMPx));
    assert_param(IS_FUNCTIONAL_STATE(State));

    WRITE_REG(ACMPx->DACCTL_bit.EN, State);
}

/**
  * @brief   Установка напряженения на выходе ЦАП REF0
  * @param   ACMPx  Выбор блока ACMP, где x лежит в диапазоне 0-2.
  * @param   refVal Уровень напряжения на выходе ЦАП
  * @param   ACMP_DAC_REFx Выбор выхода ЦАП, где x = 0|1
  * @retval  void
  */
__STATIC_INLINE void ACMP_SetRef(ACMP_TypeDef* ACMPx, uint32_t REFx, uint32_t refVal)
{
	assert_param(IS_CMP_DAC_REF(REFx));
    assert_param(IS_CMP_REFVAL(refVal));

    MODIFY_REG(ACMPx->DACCTL, 0xF << REFx, refVal << REFx);
}

/**
  * @brief   Разрешение работы компаратора ACMPx
  * @param   ACMPx  Выбор блока ACMP, где x лежит в диапазоне 0-2.
  * @param   state Бит разрешения работы
  * @retval  void
  */
__STATIC_INLINE void ACMP_Cmd(ACMP_TypeDef* ACMPx, FunctionalState state)
{
    assert_param(IS_ACMP_PERIPH(ACMPx));
    assert_param(IS_FUNCTIONAL_STATE(state));

    WRITE_REG(ACMPx->ACMPCTL_bit.DIS, !state);
}

/**
  * @brief   Сброс компаратора ACMPx
  * @param   ACMPx  Выбор блока ACMP, где x лежит в диапазоне 0-2.
  * @param   state Бит сброса
  * @retval  void
  */
__STATIC_INLINE void ACMP_RstCmd(ACMP_TypeDef* ACMPx, FunctionalState state)
{
    assert_param(IS_ACMP_PERIPH(ACMPx));
    assert_param(IS_FUNCTIONAL_STATE(state));

    WRITE_REG(ACMPx->ACMPCTL_bit.RSTN, !state);
}

/**
  * @brief   Инверсия выходного канала ACMPx
  * @param   state Бит разрешения работы
  * @param   ACMPx Выбор компаратора, где x = 0|1
  * @retval  void
  */
__STATIC_INLINE void ACMP_InvCmd(ACMP_TypeDef* ACMPx, FunctionalState state)
{
    assert_param(IS_ACMP_PERIPH(ACMPx));
    assert_param(IS_FUNCTIONAL_STATE(state));

    WRITE_REG(ACMPx->ACMPCTL_bit.INV, state);
}

/**
  * @brief   Выбор выходного сигнала, подключаемого на отрицательный выход компаратора ACMPx
  * @param   ref  Сигнал, поступающий на вход компаратора типа @ref ACMP_Ref_TypeDef
  * @param   ACMPx Выбор компаратора, где x = 0|1
  * @retval  void
  */
__STATIC_INLINE void ACMP_RefConfig(ACMP_TypeDef* ACMPx, ACMP_Ref_TypeDef ref)
{
    assert_param(IS_ACMP_PERIPH(ACMPx));
    assert_param(IS_CMP_REF(ref));

    WRITE_REG(ACMPx->ACMPCTL_bit.SELREF, ref);
}

/**
  * @brief   Выбор события для формирования прерывания ACMPx
  * @param   intSrc Событие для формирования прерывания @ref ACMP_Event_TypeDef
  * @param   ACMPx Выбор компаратора, где x = 0|1
  * @retval  void
  */
__STATIC_INLINE void ACMP_IntSourceConfig(ACMP_TypeDef* ACMPx, ACMP_Event_TypeDef intSrc)
{
    assert_param(IS_ACMP_PERIPH(ACMPx));
    assert_param(IS_CMP_INTSOURCE(intSrc));

    WRITE_REG(ACMPx->ACMPCTL_bit.INTSRC, intSrc);
}

/**
  * @brief   Выбор события ACMPx для пробуждения микроконтроллера
  * @param   trigSrc Событие для формирования сигнала пробуждения @ref ACMP_Event_TypeDef
  * @param   ACMPx Выбор компаратора, где x = 0|1
  * @retval  void
  */
__STATIC_INLINE void ACMP_TriggerSourceConfig(ACMP_TypeDef* ACMPx, ACMP_Event_TypeDef trigSrc)
{
    assert_param(IS_ACMP_PERIPH(ACMPx));
    assert_param(IS_CMP_EVENT(trigSrc));

    WRITE_REG(ACMPx->ACMPCTL_bit.TRIGSRC, trigSrc);
}

/**
  * @brief   Состояние выхода компаратора ACMPx
  * @param   ACMPx Выбор компаратора, где x = 0|1
  * @retval  status Состояние компаратора
  */
__STATIC_INLINE FunctionalState ACMP_Status(ACMP_TypeDef* ACMPx)
{
    assert_param(IS_ACMP_PERIPH(ACMPx));

    return READ_BIT(ACMPx->ACSTATUS,ACMP_ACSTATUS_STATE_Msk);
}

/**
  * @brief   Разрешение прерывания компаратора ACMPx
  * @param   ACMPx Выбор компаратора, где x = 0|1
  * @param   state Флаг разрешения прерывания
  * @retval  void
  */
__STATIC_INLINE void ACMP_ITCmd(ACMP_TypeDef* ACMPx, FunctionalState state)
{
    assert_param(IS_ACMP_PERIPH(ACMPx));
	assert_param(IS_FUNCTIONAL_STATE(state));

	WRITE_REG(ACMPx->INTEN, state);
}

/**
  * @brief   Статус немаскированного прерывания компаратора ACMPx
  * @param   ACMPx Выбор компаратора, где x = 0|1
  * @retval  state Запрос на прерывание ACMPx
  */
__STATIC_INLINE FunctionalState ACMP_ITRawStatus(ACMP_TypeDef* ACMPx)
{
    assert_param(IS_ACMP_PERIPH(ACMPx));

    return READ_BIT(ACMPx->RIS, ACMP_RIS_CMP_Msk);
}

/**
  * @brief   Статус маскированного прерывания компаратора ACMPx
  * @param   ACMPx Выбор компаратора, где x = 0|1
  * @retval  state Запрос на прерывание ACMPx
  */
__STATIC_INLINE FunctionalState ACMP_ITMaskedStatus(ACMP_TypeDef* ACMPx)
{
    assert_param(IS_ACMP_PERIPH(ACMPx));

    return READ_BIT(ACMPx->MIS, ACMP_MIS_CMP_Msk);
}

/**
  * @brief   Сброс прерывания от компаратора ACMPx
  * @param   ACMPx Выбор компаратора, где x = 0|1
  * @retval  void
  */
__STATIC_INLINE void ACMP_ITClear(ACMP_TypeDef* ACMPx)
{
    assert_param(IS_ACMP_PERIPH(ACMPx));

    WRITE_REG(ACMPx->ICLR, ACMP_ICLR_CMP_Msk);
}


/**
  * @}
  */

#ifdef __cplusplus
}
#endif

#endif /* __PLIB3T_ACMP_H */

/**
  * @}
  */

/**
  * @}
  */

/******************* (C) COPYRIGHT 2025 NIIET *****END OF FILE****/
