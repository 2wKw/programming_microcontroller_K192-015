NIIET_RISCV SDK
===============

The NIIET_RISCV SDK is a set of software development tools for NIIET's RISC-V microcontrollers

    К1921VG015

Folder structure

.
|-- doc : Microcontroller and development board documentation
|   `-- board : development board documentation
|   `-- К1921ВГ015 : К1921VG015 microcontroller documentation
|-- doc_en : Microcontroller and development board documentation in English
|   `-- К1921VG015 : К1921VG015 microcontroller documentation
|-- platform : Common libraries
|   `-- Device : Microcontrolelr header files, startup files, linker files
|
|-- projects : Project examples
|   `-- NIIET-DEV-K1921VG015 : Projects for NIIET-DEV-K1921VG015 development board
|
`-- tools : Supporting tools
    |-- openocd : Files for MCU debugging
    |-- svd : Microcontroller SVD files
    `-- sc-dt_Patch_Niiet_Win32.zip : Syntacore Development Toolkit support archive for the K1921VG015 microcontroller

Requirements and guidelines

For project assembly in GCC following software is required:

    RISCV GCC
    CMake 3.8+
    make for your operating system (make, mingw64-make …)

For project debugging following software is required:

OpenOCD K1921VG015 Flash driver

    OpenOCD K1921VG015 Flash driver

Projects for Eclipse have been created in:

    Syntacore Development Toolkit

For supporting the microcontroller K1921VG015 in Syntacore Development Toolkit it is necessary to unpack the contents of the “tools/sc-dt_Patch_Niiet_Win32.zip” archive into the “sc-dt” folder