NIIET_RISCV SDK
=========

NIIET_RISCV SDK - это набор программных средств разработки для микроконтроллеров RISC-V НИИЭТ:

- К1921VG015
- К1921VG1T
- К1921VG3T
- К1921VG5T
- К1921VG7T

Структура каталогов
-------------

```
.
|-- hardware : Исходники относящиеся к плате и периферии на ней
|   `-- bsp : Board Support Package - описание периферии, подключенной к мк на конкретной плате
|       `-- NIIET-DEV-K1921VG015 : описание периферии, подключенной к мк на плате NIIET-DEV-K1921VG015
|
|-- doc : Документация по микроконтроллерам перенесена в соседний репозиторий niiet/niiet
|
|-- platform : Общие библиотеки
|   |-- Device : Заголовочные файлы микроконтроллера, файлы startup и скрипты линкера
|   |-- middleware : Промежуточное ПО: протоколы, интерфейсы
|   |   |-- fft : Библиотека функций FFT (Fast Fourier Transform - Быстрое преобразование Фурье)
|   |   |-- FreeRTOS : Реализация FreeRTOS
|   |   `-- mbedtls : Библиотека функций Mbed TLS
|   |       `-- alt_k1921vg015 : Реализация функций с использованием аппаратных блоков K1921VG015
|   `-- plib015 : Библиотека периферии К1921ВГ015
|
|-- projects : Примеры проектов
|   |-- NIIET-DEMO-K1921VG3T : Проекты для отладочной платы NIIET-DEMO-K1921VG3T
|   |-- NIIET-DEV-K1921VG015 : Проекты для отладочной платы NIIET-DEV-K1921VG015
|   `-- plib015 : Проекты для отладочной платы NIIET-DEV-K1921VG015 с использованием библиотеки PLIB015
|
|-- templates : Шаблоны проектов
|   |-- k1921vg015-bare : Шаблон проекта для К1921ВГ015
|   `-- k1921vg015-plib015 : Шаблон проекта для К1921ВГ015 с использованием библиотеки PLIB015
|
`-- tools : Вспомогательный инструментарий
    |-- openocd : Файлы для осуществления отладки мк
    |-- svd : SVD файлы микроконтроллеров
    `-- niiet-aspect-1.0.1.vsix : Расширение для VSCode
```

[Документация по микроконтроллерам RISC-V](https://gitflic.ru/project/niiet/niiet_riscv_sdk/file/?file=doc&branch=master)

Требования и рекомендации
-------------

Для сборки проектов под GCC необходимы:

* [RISCV GCC](https://github.com/riscv-collab/riscv-gnu-toolchain)
* make для вашей ОС (make, mingw64-make ...)

Для отладки проектов необходимы:

OpenOCD с драйверами Flash K1921VG015, K1921VG3T, K1921VG3T

* [OpenOCD с драйверами Flash K1921VG015](https://gitflic.ru/project/niiet/openocd)

Проекты для Eclipse создавались в:

* [Syntacore Development Toolkit](https://syntacore.com/page/products/sw-tools/)

Для поддержки микроконтроллеров К1921ВГ015, К1921ВГ3Т, К1921ВГ5Т, К1921ВГ7Т в Syntacore Development Toolkit (ОС Windows) необходимо содержимое архива ["sc-dt_Patch_Niiet_Win32.zip"](https://gitflic.ru/project/niiet/openocd/release/4a4e7431-0990-455c-9a8b-487bc98f72f8/71506fab-f911-40da-bc25-c8a0f39e9cab/download) распаковать в каталог "sc-dt"

Для поддержки микроконтроллеров К1921ВГ015, К1921ВГ3Т, К1921ВГ5Т, К1921ВГ7Т в Syntacore Development Toolkit (ОС Linux) необходимо содержимое архива ["sc-dt_Patch_Niiet_Linux.tar.gz"](https://gitflic.ru/project/niiet/openocd/release/4a4e7431-0990-455c-9a8b-487bc98f72f8/87bb57bf-b4d3-4ce4-8f0b-85bb685facbb/download) распаковать в каталог "sc-dt"

Для поддержки микроконтроллера К1921ВГ015 в VSCode разработано расширение niiet-aspect-x.x.x.vsix. Файл расширения расположен в каталоге tools, инструкции по установке и работе с расширением приведены в п.4 [Start NIIET RISCV](https://gitflic.ru/project/niiet/niiet/blob/raw?file=doc%2FStart_NIIET_RISCV.pdf&inline=false&commit=e6dcc27fd1d70c1410026050b98352b87aed0a8e "Start NIIET RISCV")
